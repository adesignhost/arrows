<?php
/*Copyright Aidan Woodrow aDesignHost.co.uk 2020. All rights reserved. WARNING: This line must not be removed.*/
$maincats=[];
$subcats=[];
$items=[];
$allkw=[];

//1) MAIN CATEGORIES
$m=[];
//Switches between two sets of main categories for the demo. Notice they are not sorted here but even though they become named keyed arrays they will be. If you put them in the order you want then you won't need to sort which is a better option
$i=rand(0,1);
if($i===0){
$m[0]="Inkjet Cartridges";
$m[1]="Laser Toners";
$m[2]="Ribbons Dot Matrix";
$m[3]="Inkjet Refilling";
$m[4]="Inkjet Paper";
}else{
$m[]="Showing allowable characters";
$m[]="3Main   1"; //These can by anything you want and as many as you want, hard coded or from elsewhere
$m[]="2Main,2"; //Contains an allowable character
$m[]="4Main;3"; //Contains an allowable character
$m[]="9Main:4"; //Contains an allowable character
$m[]="1Main''5"; //Contains an allowable character
$m[]="10Main\"6"; //Contains an allowable character if the quote is escaped since it is within double quotes. When storing/using data you need to convert certain characters so they are code friendly
$m[]="5Ma/in/7"; //Contains an allowable character
$m[]="8M\ain\8"; //Contains an allowable character
$m[]="7Main!9"; //Contains an allowable character
$m[]="\/£$%^&'*):@#~!(}{][_¬`|.<>?=;-+"; //Contains all other allowable characters when hard coded here but if you save them to a database they should be processed using a filter of some kind. we have included one in both PHP and JS which is used to manage the sub categories only
}
$cnt=count($m); //It is always faster in PHP storing the count in a variable and then use that to loop
for($i=0;$i<$cnt;$i++){ //Resets all counters to zero and creates the array with all the fields we want
$main_cat="M".$i; //The key is used to calculate matches and must be the same as that in the items["mc"] array below.
//If you want to use the sort function on this array, rather than put them in the correct order, then the key must not begin or solely be a number. It must have an alpha prefix in order to be sorted but you can then tag on its unique fixed id number
$maincats[$main_cat]=array("mc"=>($m[$i]),"sort"=>$m[$i],"qty"=>0,"xitems"=>[]); //Creating a whole empty array
}
//When NOT using the main_cat equal random key in the demo items[] below you could create the main categories in JavaScript the same as the sort array, and store it in the same place.
//The only reason to use the PHP version would be if this information came from a database which if they do not change should be avoided just because it is slower using unnecesary resources

$sub_cat_qty=28; //This is just a demo figure but it must be the same as the random democoded maximum id value otherwise you will have missing items when you select a sub category and the main category count will be wrong. Your production version will use data from a database set up correctly by adding items and categories and linking them together so there will be no broken links. Our management tool included will help you configure main & sub categories and linked items correctly. Demo data is random and potentially unstructured

//2) SUB CATEGORIES from various PHP sources
if($func==="randomdata"){
$subcats=democoded($sub_cat_qty); //Randomly generated data for the demo only
}elseif($func==="databasedata"){
$subcats=db(); //From database
}elseif($func==="phphardwireddata"){
$subcats=phphardwired(); //If your sub categories are static and won't change then you could use this option
}elseif($func==="jshardwireddata"){
//We can't populate the $subcats array with JavaScript here because you can't do it that way around so that is done within the arrows_filter.php code which called this page
}elseif($func==="json_complete"){
//We can't populate the $subcats array with JavaScript here because you can't do it that way around so that is done within the arrows_filter.php code which called this page
}

//3) ITEMS RESULTS RANDOM DATA
//Generates some random data to show things working. This data will come from your database instead so you need to replace this code and fill the $allkw[] array with the comma separated keywords and the $items[] array with your own data.
for($id=1;$id<$sub_cat_qty*10;$id++){ //Unique items/keywords id starting at 1
$startdate=date("D jS M 'y (H:i)",strtotime(DemoData("datetime",0))); //If and when the document was updated
$title=DemoData("alpha",32);
$sorttitle=strtolower(substr($title,0,16)); //Limits string size to reduce time taken and makes the same case because upper case are sorted before lower case which is not human friendly.
$notes=DemoData("alpha",64);
$type=DemoData("alpha",8);
$dt=strtotime(DemoData("datetime",0)); //Generate random date
$added=date("D jS M 'y (H:i)",$dt); //When the item was added
$dt=strtotime(DemoData("datetime",0)); //Generate random date
$updated=date("D jS M 'y (H:i)",$dt); //If and when the document was updated
$sortdate=date("YmdHis",$dt); //It needs to be in this format year, month, day, hours, minutes, seconds 20201201235959 to sort correctly or a timestamp like $dt above
$sortdate=$dt;
$sc=rand(0,10);
if(!$maincats||$sc<1){ 
$main_cat=""; //Just for the demo to show the "Link New Items" feature we are using some blank items main_cat so they show up
$scs=""; //Just for the demo to show the "Link New Items" feature we are using some blank items scs so they show up
}else{
$rn=rand(0,$cnt-1); //Creates a random main category for the demo only. cnt is taken from above when the maincats are created
$main_cat="M".$rn; //Main category id key
if($subcats){ //If php data option chosen for the demo
$subcnt=count($subcats); //Store the count so we can pick valid id's to string together below
$scs=strval($subcats[rand(0,$subcnt-1)]["id"]); //Get the id of a valid demo sub category
for($ii=0;$ii<10;$ii++){ //Adds a string of 10 sub categories to this item. So you can add an item, say a t-shirt to the categories, tier 1:size/tier 2:small, tier 1:colour/tier 2:blue etc.
$scs.=",".strval($subcats[rand(0,$subcnt-1)]["id"]); //Random value for sub category. Note you can have the same item under several different sub categories. Just string the sub category ID numbers together separated with a comma. So 1,5,18 for instance
}
}else{ //Use JavaScript array length of 15
$subcnt=15;
$scs=strval(rand(1,$subcnt)); //Random value for sub category
//Adds a string of 10 sub categories to this item. So you can add an item, say a t-shirt to the categories, tier 1:size/tier 2:small, tier 1:colour/tier 2:blue etc.
for($ii=0;$ii<10;$ii++){ //Random data doesn't prevent duplicates but when you configure things the correct way the same sub category id wont appear more than once
$scs.=",".strval(rand(1,$subcnt)); //Note you can have the same item under several different sub categories. Just string the sub category ID numbers together separated with a comma. So 1,5,18 for instance
}
}
}
//Creates some random keywords for searching
$kwords=DemoData("num",3); //When you store keywords in to a database or any other data you should escape single and double quotes using PHP addslashes($str);
for($ii=0;$ii<5;$ii++){
$kwords.=",".DemoData("alpha",3);
}
//$kwords="\/£$%^&'*):@#~!\"(}{][_¬`|.<>?=;-+"; //This contains an escaped \ double quotes in the middle otherwise the code would error. It is an instruction and does not show or is part of the search string. You always need to ensure user inputed data is encoded to prevent corrupt data
$id=strval($id); //Makes it a string which can be important when used
	$allkw[]=array("kwords"=>$kwords,"id"=>$id); //If you don't want a search facility then just // this line out and don't put anything in the $kwords above
$items[]=array("id"=>$id,"mc"=>$main_cat,"scs"=>$scs,"title"=>($title)
,"sortdate"=>$sortdate,"added"=>$startdate,"sorttitle"=>($sorttitle),"notes"=>($notes),"added"=>$added,"type"=>$type,"updated"=>$updated); //This array must contain the hidden fields 'id', 'mc' as a string and 'scs' also a string with comma separated numbers. 'title' is used for the search results so it must be included too. 'id' must be unique but does not have to be consecutive. This id in allkw[] and items[] must be the same each loop. The rest can be anything you want to use and/or display on the web page. You simply create a template and insert the field names you've chosen here in-between »arrow tags« It will then show the corresponding values. You also need to use the field names in the sort order options.
}

////

function DemoData($typ="alpha",$length=10){ //Generates some random data to show things working. This data will come from your database instead.
$data="";
if($typ=="alpha"||$typ=="num"){
if($typ=="alpha"){
$range="ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijkmnopqrstuvwxyz";
}else{
$range="1234567890";
}
for($i=0;$i<$length;$i++){
$char=substr($range,mt_rand(0,strlen($range)-1),1);
if(!strstr($data,$char)){
$data.=$char;
}
}
}elseif($typ=="date"){
$y=mt_rand(2010,2020);
$m=mt_rand(1,12);
$d=mt_rand(1,28);
$data=$y."-".$m."-".$d;
}elseif($typ=="time"){
$h=mt_rand(1,24);
$i=mt_rand(0,59);
$s=mt_rand(0,59);
$data=$h.":".$i.":".$s;
}elseif($typ=="datetime"){
$y=mt_rand(2010,2020);
$m=mt_rand(1,12);
$d=mt_rand(1,28);
$h=mt_rand(1,24);
$i=mt_rand(0,59);
$s=mt_rand(0,59);
$data=$y."/".$m."/".$d." ".$h.":".$i.":".$s;
}elseif($typ=="sortdate"){
$y=mt_rand(2010,2020);
$m=mt_rand(1,12);
$d=mt_rand(1,28);
$data=$y.$m.$d;
}
return $data;
}

//SUB CATEGORIES DATA
function db(){ //Pull straight from the database and store in an array
	return democoded(10); //Since we're not actually connecting to a valid database in the demo

$dbi=dbi_connect(""); //You need to add your own code to connect to your database here
$q=mysqli_query($dbi,"select * from demo_cats"); //You do not need to use the sort function which is slow and puts load on the server. We are using JS to sort instead, client side.
$subcats=[]; //Note: The parentid of all the first tier selections must be 0. Other parentid's much match a valid unique id entry which must be greater than zero
while($r=mysqli_fetch_array($q)){
extract($r); //Converts to standard $arrays instead of $r["arrays"] so the quotes don't get in the way.
//You just need to populate this array and all fields correctly leaving those [] blank.
//id is the unique number and parentid is the id that particular id is located under like a tree branch
$subcats[]=array("parentid"=>strval($parentid),"id"=>strval($id),"xsubs"=>[],"xitems"=>[],"name"=>($name),"sort"=>strval((float)$sort),"qty"=>0,"tf"=>""); //Sort field must be a number in the format of a string
}
return $subcats;
}

////

function democoded($sub_cat_qty){ //generates any categories to show the product working
$subcats=[]; //note: the parentid of all the first tier selections must be 0. other parentid's much match a valid unique id entry which must be greater than zero
$demo_subs=intval($sub_cat_qty/4); //for the demo it makes sure there are sub categories and also tier 2 sub categories. it doesn't make sure only tier 1 have a tier 2. Being random tier 2 can also have a tier 3 but these will not be shown. This is also possible if you store your own category details but this tool does not cater for more than 2 tiers as that covers most if not all situations. We always have to supply valid data to functions.
for($i=1;$i<$demo_subs;$i++){ //generates selections.
$selection="Tier 1 Selection: ".$i;
$subcats[]=array("parentid"=>strval(0),"id"=>strval($i),"xsubs"=>[],"xitems"=>[],"name"=>($selection),"sort"=>strval((float)$i),"qty"=>0,"tf"=>""); //including a sort field allows greater control over the sort order. Using the invisible field you can sort in any way shape or form you want.
}
for($i=$demo_subs;$i<$sub_cat_qty;$i++){ //generates more sub selections.
$parentid=rand(1,$demo_subs-1); //you should ensure that sub categories are not more than 2 tiers because the data will be stored but never used which will slow things down. if you remove the /4 above it will allow numbers that include tier 2 sub categories as parents. Although this won't result in an actual error you need to use a proper categories management tool to keep things tidy and correct otherwise things may be missing. Broken branches should be avoided too such as leaving a tier 2 sub category without its parent.
$selection="Tier 2 Selection: ".$i;
$subcats[]=array("parentid"=>strval($parentid),"id"=>strval($i),"xsubs"=>[],"xitems"=>[],"name"=>($selection),"sort"=>strval((float)$i),"qty"=>0,"tf"=>""); //If you are going to sort these numerically then the $sort must be an integer else it must be a string.
}
return $subcats;
}

////

function phphardwired(){ //If the options are your own and fixed semi-permanently and there are not many it might be a better idea to hard code them like this instead of using a database for absolutely everything because it is slightly quicker and easier.
$subcats=[]; //Note: the parentid of all the first tier selections must be 0. other parentid's much match a valid unique id entry
//Including a sort field allows greater control over the sort order. Using the invisible field you can sort in any way shape or form you want.
$subcats[]=array("parentid"=>strval(0),"id"=>strval(1),"xsubs"=>[],"xitems"=>[],"name"=>"Selection 1","sort"=>"1","qty"=>0,"tf"=>""); 
$subcats[]=array("parentid"=>strval(0),"id"=>strval(2),"xsubs"=>[],"xitems"=>[],"name"=>"Selection 2","sort"=>"2","qty"=>0,"tf"=>""); 
$subcats[]=array("parentid"=>strval(0),"id"=>strval(3),"xsubs"=>[],"xitems"=>[],"name"=>"Selection 3","sort"=>"3","qty"=>0,"tf"=>""); 
$subcats[]=array("parentid"=>strval(0),"id"=>strval(4),"xsubs"=>[],"xitems"=>[],"name"=>"Selection 4","sort"=>"4","qty"=>0,"tf"=>""); 
$subcats[]=array("parentid"=>strval(0),"id"=>strval(5),"xsubs"=>[],"xitems"=>[],"name"=>"Selection 5","sort"=>"5","qty"=>0,"tf"=>""); 
$subcats[]=array("parentid"=>strval(0),"id"=>strval(6),"xsubs"=>[],"xitems"=>[],"name"=>"Selection 6","sort"=>"6","qty"=>0,"tf"=>""); 
$subcats[]=array("parentid"=>strval(0),"id"=>strval(7),"xsubs"=>[],"xitems"=>[],"name"=>"Selection 7","sort"=>"7","qty"=>0,"tf"=>""); 

$subcats[]=array("parentid"=>strval(1),"id"=>strval(8),"xsubs"=>[],"xitems"=>[],"name"=>"Selection 8","sort"=>"8","qty"=>0,"tf"=>""); 
$subcats[]=array("parentid"=>strval(1),"id"=>strval(9),"xsubs"=>[],"xitems"=>[],"name"=>"Selection 9","sort"=>"9","qty"=>0,"tf"=>""); 
$subcats[]=array("parentid"=>strval(1),"id"=>strval(10),"xsubs"=>[],"xitems"=>[],"name"=>"Selection 10","sort"=>"10","qty"=>0,"tf"=>"");

$subcats[]=array("parentid"=>strval(4),"id"=>strval(11),"xsubs"=>[],"xitems"=>[],"name"=>"Selection 11","sort"=>"8","qty"=>0,"tf"=>""); 
$subcats[]=array("parentid"=>strval(4),"id"=>strval(12),"xsubs"=>[],"xitems"=>[],"name"=>"Selection 12","sort"=>"9","qty"=>0,"tf"=>""); 
$subcats[]=array("parentid"=>strval(4),"id"=>strval(13),"xsubs"=>[],"xitems"=>[],"name"=>"Selection 13","sort"=>"10","qty"=>0,"tf"=>""); 

$subcats[]=array("parentid"=>strval(7),"id"=>strval(14),"xsubs"=>[],"xitems"=>[],"name"=>"Selection 14","sort"=>"8","qty"=>0,"tf"=>""); 
$subcats[]=array("parentid"=>strval(7),"id"=>strval(15),"xsubs"=>[],"xitems"=>[],"name"=>"Selection 15","sort"=>"9","qty"=>0,"tf"=>""); 
$subcats[]=array("parentid"=>strval(7),"id"=>strval(16),"xsubs"=>[],"xitems"=>[],"name"=>"Selection 16","sort"=>"10","qty"=>0,"tf"=>""); 
return $subcats;
}
?>

<script>
function jshardwired(){ //If these options do not change then you should store this in a .js file instead which could then be cached saving even more server load, time and ultimately money
var subcats=[];
subcats.length=0;
subcats.push({"parentid":"0","id":"1","xsubs":[],"xitems":[],"name":"Selection 1","sort":"1","qty":0,"tf":""});
subcats.push({"parentid":"0","id":"2","xsubs":[],"xitems":[],"name":"Selection 2","sort":"2","qty":0,"tf":""});
subcats.push({"parentid":"0","id":"3","xsubs":[],"xitems":[],"name":"Selection 3","sort":"3","qty":0,"tf":""});
subcats.push({"parentid":"0","id":"4","xsubs":[],"xitems":[],"name":"Selection 4","sort":"4","qty":0,"tf":""});
subcats.push({"parentid":"0","id":"5","xsubs":[],"xitems":[],"name":"Selection 5","sort":"5","qty":0,"tf":""});
subcats.push({"parentid":"0","id":"6","xsubs":[],"xitems":[],"name":"Selection 6","sort":"6","qty":0,"tf":""});
subcats.push({"parentid":"0","id":"7","xsubs":[],"xitems":[],"name":"Selection 7","sort":"7","qty":0,"tf":""});

subcats.push({"parentid":"1","id":"8","xsubs":[],"xitems":[],"name":"Selection 8","sort":"8","qty":0,"tf":""});
subcats.push({"parentid":"1","id":"9","xsubs":[],"xitems":[],"name":"Selection 9","sort":"9","qty":0,"tf":""});
subcats.push({"parentid":"1","id":"10","xsubs":[],"xitems":[],"name":"Selection 10","sort":"10","qty":0,"tf":""});

subcats.push({"parentid":"3","id":"11","xsubs":[],"xitems":[],"name":"Selection 11","sort":"11","qty":0,"tf":""});
subcats.push({"parentid":"5","id":"12","xsubs":[],"xitems":[],"name":"Selection 12","sort":"12","qty":0,"tf":""});
subcats.push({"parentid":"7","id":"13","xsubs":[],"xitems":[],"name":"Selection 13","sort":"13","qty":0,"tf":""});
return subcats;
}

////

function json_complete(){ //same as above but not as user friendly if anything needs changing
var subcats=[{"parentid":"0","id":"1","xsubs":[],"xitems":[],"name":"Selection 1","sort":"1","qty":0,"tf":""},{"parentid":"0","id":"2","xsubs":[],"xitems":[],"name":"Selection 2","sort":"2","qty":0,"tf":""},{"parentid":"0","id":"3","xsubs":[],"xitems":[],"name":"Selection 3","sort":"3","qty":0,"tf":""},{"parentid":"0","id":"4","xsubs":[],"xitems":[],"name":"Selection 4","sort":"4","qty":0,"tf":""},{"parentid":"0","id":"5","xsubs":[],"xitems":[],"name":"Selection 5","sort":"5","qty":0,"tf":""},{"parentid":"0","id":"6","xsubs":[],"xitems":[],"name":"Selection 6","sort":"6","qty":0,"tf":""},{"parentid":"0","id":"7","xsubs":[],"xitems":[],"name":"Selection 7","sort":"7","qty":0,"tf":""},{"parentid":"1","id":"8","xsubs":[],"xitems":[],"name":"Selection 8","sort":"8","qty":0,"tf":""},{"parentid":"1","id":"9","xsubs":[],"xitems":[],"name":"Selection 9","sort":"9","qty":0,"tf":""},{"parentid":"1","id":"10","xsubs":[],"xitems":[],"name":"Selection 10","sort":"10","qty":0,"tf":""}]
return subcats;
//In theory you could save/update this info to .js files bypassing the need to use the database all the time making it even quicker. Or hard wire it like this if the selectable options are static. It would be better storing all arrays in a .js file because they can be downloaded once and cached for future use without needing to retrieve them again and again. A better method suited only for static pages but not dynamic ones. But it is worth doing because it further reduces download payload sizes and database usage making everything even faster and cheaper. It's a win, win combination. Storing the data in a PHP file as we do here is very good but if they close the browser that data is lost and will have to be retrieved and downloaded again. A cached .js file will simply be taken from the browser storage only.
}
</script>