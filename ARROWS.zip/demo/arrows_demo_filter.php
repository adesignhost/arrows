<?php
/*Copyright Aidan Woodrow aDesignHost.co.uk 2021. All rights reserved. WARNING: This line must not be removed.*/
include("arrows_demo_data.php"); //Collecting all the data. Contains some random data functions you won't need for your production version as your category and items data will come from elsewhere
//Now the arrays are full with data we JSON encode them so they can be used in JavaScript
	$mc="PHP";
	if($mc==="PHP"){ //use main categories generated using PHP rather than JavaScript
	$maincats=json_encode($maincats); //Main categories converted to JSON unless you use a JavaScript version as outlined below
	}
	$subcats=json_encode($subcats); //Sub categories converted to JSON
$items=json_encode($items); //Result items converted to JSON
$kwords=json_encode($allkw); //Search keywords converted to JSON
?>
<!--Side menus go in here-->
<tr><td class="vatop">
<div id="options" class="sidebar aleft"></div>
</td>
<!--Main content goes here-->
<td class="vatop tbl">
<div class="acenter vlcorner gbg heading">Versatile Menu & Content Filter with Search Facility & Management Functions</div>
<div class="acenter whhead">»ARROWS«<div class="acenter wh">"Makes doing something very useful, very easy and very fast"</div></div>
<div class="acenter wh" id="result_count"></div> <!--Position to show records found. You can remove if you don't want to display this but you also need to remove the line which populates this id in the arrows_filter.js too-->
<div id="search_results"></div> <!--Keyword results-->
<div id="show_results"></div> <!--Selection results-->
<div id="morecontent" class="wh"></div> <!--More content can be displayed here or where ever you choose-->
</td></tr>
<script>
////Transfers all collected data from PHP to JavaScript where that was the source
var items=(<?php echo $items?>); //Transfers it to JavaScript we can use it client/browser side

////1) MAIN CATEGORIES JS/PHP SOURCE OPTIONS
//You don't need to sort these if you put them in the correct order so that function can be missed out and the sort field can be removed
//If you are going to sort it then you must use a character prefix (as numbers can become indexes and we want to use keys) in the key with the same unique id number that will also be stored in the items[] array, where its data will come from a database
//As long as the main_cat in the items[] array is a correct match with one of these maincats[keys] so M0, M1 etc then it is the same
var mc="<?php echo $mc?>"; //As long as the data is stored in a JavaScript array object then it doesn't matter where the original data was stored previously. Choose either JS (recommended) or PHP/ASP. Even if the data resides in a database, if it doesn't change, then you should retrieve it and store it as below to save time and resources
if(mc==="JS"){ //Fill entries using JavaScript
var maincats=[]; //Always prefix the key name with an 'm' or another letter
maincats["M0"]={"mc":"Inkjet Cartridges","sort":"10","qty":0,"xitems":[]};
maincats["M1"]={"mc":"Laser Toners","sort":"10","qty":0,"xitems":[]};
maincats["M2"]={"mc":"Ribbons Dot Matrix","sort":"10","qty":0,"xitems":[]};
maincats["M3"]={"mc":"Inkjet Refilling","sort":"10","qty":0,"xitems":[]};
maincats["M4"]={"mc":"Inkjet Paper","sort":"10","qty":0,"xitems":[]};
}else if(mc==="PHP"){ //Obtain data from PHP source code
var maincats=(<?php echo $maincats?>); //Must not put in any " ' quote marks ' "
}
maincats=sort_object(maincats,"sort","A",true); //Sort a named-key object by the "sort" field Alphabetically keeping its original key value. If you store them already sorted (advised) then you won't need to do this


////2) SUB CATEGORIES 
var subcats=[];
	var func="<?php echo $func?>"; //transfer function value to JS
	if(func==="jshardwireddata"){
	subcats=jshardwired(); //use hard wired JSON
	}else if(func==="jsoncompletedata"){
	subcats=json_complete();
	}else if(func==="nodata"){
	subcats.length=0;
	}else{
subcats=(<?php echo $subcats?>); //If you don't use either of the JavaScript sub category options above then you can remove those few lines and keep this one
if(subcats.length===0){ //If you haven't defined the sub categories properly yet it will use the items array scs field to create something that at least works for the time being but will have only 1 tier and it won't adapt for multiples strung together plus you have little control over the visible name and sort order data which is the advantage of having a separate sub categories array table which is also easier to manage. Sometimes this technique might be sufficient for you.
var sc=[],id,i,key,keys=[],l=items.length;
sc.length=0;
for(i=0;i<l;i++){
sc[items[i]["scs"].toString()]=1; //Creates unique keys using the items sub categories field data providing you have put something in there
}
keys=get_keys(sc);
l=keys.length;
for(key=0;key<l;key++){ //Loop through all the unique sorted keys to create a sub categories list
id=keys[key];
subcats.push({"parentid":0,"id":id,"xsubs":[],"xitems":[],"name":id,"sort":id,"qty":0,"tf":""});
}
}
	}

subcats=sortjsonfld(subcats,"sort","N"); //Easier managing sort orders using Numbers only. If you want to sort Alphabetically then just change the value "sort" to "name" and change "N" to "A" 
cats_xsubs(); //Collate all the sub categories by index an option may have. Warning: This must and only be performed after sorting subcats and not before


//6) Sorting data
var srt_fld="sorttitle"; //This field can be anything defined in items[] It doesn't matter if this data is displayed on screen or not
var option="Title"; //This field is for the default option name
var slctd="t1sel"; //Default style class needs putting on the same line as srt_fld. t1 is unselected and t1sel is the selected style
var sortops=[]; //We don't sort these because the list is short so the order they are in here is the order they will be on the page
sortops.length=0;
//You can add as many as you like. You just need to make sure the "id":"field name" matches something in the items[] array whether it appears on screen or not
sortops.push({"id":srt_fld,"AN":"A","class":slctd,"option":option}); //Default sort field has the 'srt_fld' and 'slctd' variables
sortops.push({"id":"sortdate","AN":"N","class":"t1","option":"Date Updated"}); //AN donates 'A' for Alphabetical order or 'N' for Numerical order. For this data we must use the 'N' option
sortops.push({"id":"type","AN":"A","class":"t1","option":"Type"}); //id's must match items[] array field names


////7) JavaScript Global settings
var result="arrows"; //Unique page identifier so you can run other code through the same universal filter and perform specific tasks based on the result value.
var manage=false; //Allows you to edit associated item main and sub categories when set to true.
var main_sub=true; //true = main category selection dominates / false = sub category selection dominates. The demo allows you to toggle this option but you would hard code it.
//true means when you click a main category it will process what sub categories are related to it. false is the other way around so when you select a sub category it will process what main categories are related to it
//This is different to yourself swapping the main and sub categories in the original code because main categories are single select only but sub categories can be either single or multi select.
var and_subs=false; //true means item matches must be present in all sub category tier 1/2 blocks except its own block. false for 'or' results. If main_sub is set to false this parameter will be ignored
var one_block_subs=false; //If true only one selection per tier 1/2 blocks will be allowed. false will allow any number of valid selections in the same block
var rcbox="multi".toLowerCase(); //Determines whether sub categories are single or multi select. This will override any settings above if there is a conflict. Options: single or multi
var auto_sel_tier2=true; //If true when a tier 1 sub category is selected (multi select only) it will also select all tier 2 sub categories under it. false will not. You can still unselect them individually afterwards


////8) Display all side menu options
//Display Templates only
sortoptions_template("Sort Options"); //Result is used to distinguish it from another separate complete system
main_category_template("Main Categories"); //Display main categories template only
sub_category_template("Sub Categories"); //Display sub categories template only


////9) Incorporate keywords search facility
var kwords=(<?php echo $kwords?>); //Transfers search keywords to JS from PHP
var min_search_len=1; //Minimum user input string length to perform the search. 1 means if they type just one letter it will begin to search. 2 or 3 should be used ideally to prevent too many matches
if(kwords.length>0){ //Render search template if there is any data to search. 
kwords=keywords(kwords,min_search_len); //Sorts and processes keywords
search_template(result,"Search","title"); //result=unique id, "Search" is the heading, "?" is an items field to show as the titles
}


////10) Display data
sortoptions(result,sortops); //Insert sort options in to template
hl_sort(result,srt_fld,"A"); //Sorts items[] array using the field name in 'srt_fld' Alphabetically which in turn calibrates linked items with sub categories and also main categories if 'main_sub' is set to false above
if(main_sub===true){
show_main_cats(result); //Shows main categories only first
}else{
sub_cats_2tiers(result); //Shows sub categories only first
}

	////Manage options (When you click on the items manage options the variable manage becomes true so you can see and use its functions but does not return to false unless you refresh the whole page) 
	//This feature and associated code should only reside on a local machine, not on an on-line server so only you can make any changes.
	//if(manage===true){
	document.getElementById("options").innerHTML+=document.getElementById(result+"_manageoptions").innerHTML;
	main_sub_dominance(result);	//You would normally remove this line and function as a user option and hard code your 'main_sub' =true or =false choice. This is only here to show case the demo
	single_multi(result); //Toggle sub category single or multi select. You can remove this line and associated code as an end user option and hard wire your desired 'rcbox' choice above
	and_or_subs(result,and_subs); //Toggle sub and sub block / sub or sub block. You can remove this line and associated code as an end user option and hard wire your desired 'and_subs' choice above
	one_per_group(result,one_block_subs); //Show demo option to change number of selections per Tier 1/2 block
	document.getElementById("options").innerHTML+=document.getElementById(result+"_generaloptions").innerHTML; //Shows general options but if you do not want to display any of your own then you can remove this line and any associated code. It's not technically part of the filter. It's just here to show information in the easiest way possible.
	//}

	document.getElementById("show_results").innerHTML="<div class='wh'>Congratulations:<br>You are now using the fastest (most efficient) navigation filter in town.<br><br>This tool will continue to work <u><i>without</i></u> an internet connection from this point on. Unless you change the data source or use the, not normally, integrated manage tool for local use only.<br><br>It saves energy by using less server & local hardware resources which in turn reduces CO² emissions.<br><br>Millennials do everything at a hundred miles an hour. Google's motto is \"The internet should be fast\" We all use the internet and have experienced websites (even by the biggest companies we know) that are frustratingly slow. We expect technology to be faster than we are and anything that does not meet this standard is rejected for those which do.<br><br>It isn't people's internet connection that is slowing things down, servers are the weakest link. You either spend more money on more powerful servers or you spend a little money on faster software which saves you more money on expensive servers.<br><br>It was originally created exclusively for only ourselves but later decided to release it to the public (with instructions) because we thought everybody else should be using it too as it isn't just a web tool it is a climate change benefit solution as well. We then had to build a specific site so we could sell it. Depending on interest we may release other tools but for now this is the only one. It's even free (subject to promotional terms) so at least give it a try before parting with your money. It may not look much on the surface to the casual observer. We'd rather is was better than initial expectations than the other way around.<br><br>Norwegian Håkon Wium Lie, back in 1994 sought to create a universal standardised style sheet for the World Wide Web. He went on to co-create CSS1, CSS2 and RFC 2318 versions with Tim Berners-Lee and Robert Cailliau. In its first decade of existence (1994–2004) CSS, in all its specifications, became an established web standard greatly influencing the look and accessibility of the world wide web as we know it today. CSS3 was issued in 1999. It is the best, most efficient way to design websites which is why practically every site uses it today. This system is the same kind of concept with regards to ease of use and efficiencies. So we hope you can find many uses for it and replace existing inefficient power hungry code.<br><br>To Download & Register Our Code. (Free, Affiliate or paid versions):<br>Sign-up using just an email address and password then log-in.<br><br>Live (Free Try Before You Buy) availability date: Sunday 31st October 2021<br>Live commercially available date: To Be Determined. Try it first & let us know what needs improving.</div>";
</script>