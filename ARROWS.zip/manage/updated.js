/*Copyright Aidan Woodrow aDesignHost.co.uk 2021. All rights reserved. WARNING: This line must not be removed.*/
var i;
cats.length=0; //Clearing tree restore point
catscnt=0; //Clearing tree restore point count

switch(j["func"]){

case "edited":
oids.length=0;
oids[0]=j["id"]; //Tree re-open branch id
if(j["status"]===true){ //Since we are using triple === the status must be a boolean otherwise you may wish to use double == instead with either true/false or 1/0 
for(i=0;i<subcats.length;i++){
if(j["id"]==subcats[i]["id"]){
subcats[i]["name"]=j["name"].toString(); //Updates JSON data already filtered using PHP
subcats[i]["sort"]=j["sort"].toString(); //Updates JSON data
break;
}
}
mesg="Category edited successfully";
}else{
mesg="Something went wrong editing the category";
}
break;

case "added":
if(j["status"]===true){ //Since we are using triple === the status must be a boolean otherwise you may wish to use double == instead with either true/false or 1/0
//In the tree tool all categories are shown, including new branches and all tiers even above two but the arrows tools doesn't display tier 2 categories without any items linked to them or any branches after tier 2
oids.length=0;
subcats.push({"parentid":j['parentid'].toString(),"id":j['nid'].toString(),"xsubs":[],"xitems":[],"name":j['name'].toString(),"sort":j['sort'].toString(),"qty":0,"tf":""}); //Inserts new JSON data
//Tree re-open branch id
if(j['parentid']>0){
cats[catscnt]=j['parentid']+"-scs";
catscnt++;
oids[0]=j['parentid'];
}else{
oids[0]=j['nid'];
}
mesg="Category added successfully<br>Note: When you return to the previous<br>screen all new categories will not display<br>because they have no items linked with them.";
}else{
mesg="Something went wrong adding the category";
}
break;

case "moved":
oids.length=0;
if(j["status"]===true){ //Since we are using triple === the status must be a boolean otherwise you may wish to use double == instead with either true/false or 1/0
for(i=0;i<subcats.length;i++){
if(j["id"]==subcats[i]["id"]){
oids[0]=j["id"]; //Tree re-open branch id
subcats[i]["parentid"]=j["parentid"].toString(); //Updates JSON data
mesg="Category moved successfully";
break;
}
}
}else{
mesg="Something went wrong moving the category";
}
break;

case "deleted":
if(j["status"]===true){ //Since we are using triple === the status must be a boolean otherwise you may wish to use double == instead with either true/false or 1/0
mesg="Category deleted successfully";
}else{
mesg="Something went wrong deleting the category";
}
break;

case "updatelinked":
if(j["status"]===true){ //Since we are using triple === the status must be a boolean otherwise you may wish to use double == instead with either true/false or 1/0
items[j["xid"]]["mc"]=j["mc"]; //Update items main category
items[j["xid"]]["scs"]=j["scs"]; //Update items sub category
mesg="Linked categories updated successfully";
}else{
mesg="Something went wrong updating the linked categories";
}
break;

default:
j["status"]=false;
mesg="Action not allowed.<br>Please try again.";
}

if(j["status"]===true){ //Since we are using triple === the status must be a boolean otherwise you may wish to use double == instead with either true/false or 1/0
window.top.window.msg(1,mesg); //Display success message
if(j["func"]==="added"||j["func"]==="edited"){ //Moving and deleting doesn't change the independent sort orders only their relative positions in the tree. Changing the sort order afterwards may be required
subcats=sortjsonfld(subcats,"sort","N"); //Sorts sub categories using 'sort' field Numerically only if sort order may have changed
cats_xsubs(); //Reconfigure tier 1/2 categories now indexes have changed
ljs("manage/categories"); //Perform JavaScript showing revised category tree
}
}else{
window.top.window.msg(0,mesg); //Display error message
}