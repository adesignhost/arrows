/*Copyright Aidan Woodrow aDesignHost.co.uk 2021. All rights reserved. WARNING: This line must not be removed.*/
var j=[],oids=[],cats=[],open_obj=[],mt,catscnt; //Globals
oids[0]=0;
catscnt=0;

function ljs(inc){ //Brings in JS code to perform usually, but not exclusively, after running server code
var js=document.createElement("script");js.type="text/javascript";js.async=true;js.src=inc+".js";
document.body.appendChild(js);
}

function ajax(obj,querystring,MGP,php,js){
MGP=MGP.toUpperCase();
var xmlhttp;
if(window.XMLHttpRequest){ //Supported by common popular browsers
xmlhttp=new XMLHttpRequest();
}else if(window.ActiveXObject){ //Supported by MicroSoft browsers only
var ActiveXObject;
xmlhttp=new ActiveXObject('Microsoft.XMLHTTP');
}else{
alert("Outdated Browser Detected.<br>Please update your browser."); //Browser does not support AJAX
}
try{
xmlhttp.onreadystatechange=function(){
if(xmlhttp.readyState===4&&xmlhttp.status===200){ //Wait until page is ready and exists
if(MGP==="JGET"||MGP==="JPOST"){
//JSON data only, not HTML
j=JSON.parse(xmlhttp.responseText); //JSON is not a built in function for ie 6/7 but will work in everything else. See tutorials in order to make it work in such very old browsers
}else{
document.getElementById("mainframe").style.display="none"; //Hide main content
document.getElementById(obj).innerHTML=xmlhttp.responseText; //Insert HTML code in to id OBJ
document.getElementById(obj).style.display="block"; //Make id OBJ visible
}
if(js!==""){ //Call back after PHP code if set
ljs(js); //Perform JavaScript code
}
}
};
}
catch(ex){
alert("ERROR! Please try again.");
}
if(MGP==="GET"||MGP==="JGET"){ //Used for standard data
xmlhttp.open("GET",php+".php",true); //Retrieves code, true = asynchronous. false is no longer an option
xmlhttp.send(querystring); //Appends querystring ?name=value&name1=value1 etc
}else if(MGP==="POST"||MGP==="JPOST"){ //Used when posting form/user inputted data. Does not have size limitations like GET and is slower but required when updating a database and server interaction 
xmlhttp.open("POST",php+".php",true); //Use for personal data and in conjunction with SSL and pick up as $_POST for added security
xmlhttp.setRequestHeader("Content-type","application/x-www-form-urlencoded"); //Must ensure that any & symbols within variables are encoded using encodeURIComponent() or rawurlencode() in PHP otherwise they will interfere with the querystring elements
xmlhttp.send(querystring);
}
}

////

function aj(js){
ljs(js); //Load/run some JavaScript code
document.getElementById("mainframe").style.display="none"; //Hide id mainframe
document.getElementById("puw").style.display="block"; //Make id puw visible
}

////

function ajax_form(obj,frm,func,q,MGP,php,js){
var ofrm=document.getElementById(frm);
var i,l=ofrm.length;
var elem=[],key,keys=[],qstr="func="+func+"&q="+q;
for(i=0;i<l;i++){
if(ofrm.elements[i].getAttribute("type")==="checkbox"||ofrm.elements[i].getAttribute("type")==="radio"){
if(ofrm.elements[i].checked===true){
if(!elem[ofrm.elements[i].name]){
elem[ofrm.elements[i].name]={"val":[]};
}
elem[ofrm.elements[i].name]["val"].push(ofrm.elements[i].value); //Temporarily stores check box selections
}
}else if(ofrm.elements[i].getAttribute("type")==="text"||ofrm.elements[i].getAttribute("type")==="hidden"){
qstr+="&"+ofrm.elements[i].name+"="+encodeURIComponent(ofrm.elements[i].value); //Appends querystring with &name=value data
}
}
keys=get_keys(elem);
l=keys.length;
for(key=0;key<l;key++){
qstr+="&"+keys[key]+"="+elem[keys[key]]["val"].join(","); //Loops through any check box selections and appends them to querystring too
}
ajax(obj,qstr,MGP,php,js); //Goes to ajax so it can send the querystring data to a specified location and perform tasks based upon that data
}

////

function displayform(treeid,v){ //Displays forms
var oHTML,kk,k,str,span,flds;
oHTML="<tr><td>";
oHTML+="<table class='fw'>";
kk=v.length;
for(k=0;k<kk;k++){
str="";
span="<span class='txtblk'>&nbsp;"+v[k]["tip"]+"</span>"; //Title note

if(v[k]["type"]==="hidden"){
str="<tr><td><input type='hidden'";
str+=" id=\""+v[k]["name"]+"\"";
str+=" name=\""+v[k]["name"]+"\"";
str+=" value=\""+v[k]["value"]+"\"></td></tr>";

}else if(v[k]["type"]==="text"){
str="<tr><td class='aleft'><input value='"+v[k]["value"]+"'";
str+=" type=\"text\"";
if(v[k]["max"]==="readonly"){
str+=" "+v[k]["max"];
str+=" class=\""+v[k]["class"]+" textreadonly\"";
}else{
str+=" maxlength=\""+v[k]["max"]+"\"";
str+=" class=\""+v[k]["class"]+"\"";
}
str+=" id=\""+v[k]["name"]+"\"";
str+=" name=\""+v[k]["name"]+"\"";
str+=" tabindex=\""+k+"\">";
str+=span+"</td></tr>";

}else if(v[k]["type"]==="radio"){
str="<tr><td class='aleft'><input style='margin:0px;' type='"+v[k]["type"]+"'";
if(v[k]["edit"]===true){
flds=v[k]["value"].split(",");
str+=" onclick=\"EditTree('0','"+flds[2]+"','"+flds[0]+"','','"+flds[1]+"','0')\"";
}
str+=""+v[k]["chkd"];
str+=" id=\""+v[k]["name"]+"-"+v[k]["value"]+"\"";
str+=" name=\""+v[k]["name"]+"\"";
str+=" value='"+v[k]["value"]+"'";
str+=" tabindex='"+k+"'>";
str+="<span class=\""+v[k]["class"]+"\">&nbsp;"+v[k]["options"]+"</span></td></tr>";

}else if(v[k]["type"]==="tree"){
str="<tr><td class='fw'><div class='scroller'><div class='"+v[k]["class"]+"'>";
str+=display_tree_index(0,v[k]["options"],v[k]["name"],0,v[k]["edit"]);
str+="</div></div></td></tr>";
}
oHTML+=str;
}
oHTML+="</table></td></tr>";

document.getElementById(treeid).innerHTML=oHTML;
}

////

function display_tree_index(parent,menu,name,tier,edit){ //Displays an open/close tree with unlimited branches
var mp,mpp,toHTML="",id,exp,title,ind,lnk,l,indexid;
if(menu["parents"][parent]){
if(parent>0){
id=parent+"-"+name;
toHTML+="<div style='display:none;' id='div_"+id+"'>";
tier=tier+3; //Number of spaces to tag together for each new tier
}
mpp=menu["parents"][parent];
for(mp=0;mp<mpp.length;mp++){
indexid=menu["parents"][parent][mp];
id=menu["items"][indexid]["id"]+"-"+name; //Unique id to identify each option selection
lnk="<input type='"+menu["items"][0]["type"]+"' "+menu["items"][indexid]["chkd"]+" name='"+name+"' id='"+id+"' value='"+menu["items"][indexid]["id"]+"'";
if(edit===false){ //If you want to fill the text boxes with the relevant branch click selection for editing purposes
lnk+=">"; //Close input tag
}else{
//title only needs to be further encoded to prevent corrupt characters interfering with code
lnk+=" onclick=\"EditTree('"+menu["items"][indexid]["parentid"]+"','"+id+"','"+menu["items"][0]["titleid"]+"','"+(encodeURIComponent(menu["items"][indexid]["title"]))+"','"+menu["items"][0]["sortid"]+"','"+menu["items"][indexid]["sort"]+"')\">"; //Append click option
}
ind="";
for(l=0;l<tier;l++){
ind+="&nbsp;"; //Creates the tree branch indents
}
//title here is already filtered as above but does not require extra encoding because it prints to screen not passed through a function
title="<span>"+(menu["items"][indexid]["title"])+" (Sort: "+menu["items"][indexid]["sort"]+") [Linked: "+menu["items"][indexid]["iqty"]+"]"+"</span>";
if(!menu["parents"][menu["items"][indexid]["id"]]){ //We need to convert the index back in to the id because the parent array uses id number keys so we don't have to search loop to find what we want
toHTML+="<div>"+ind+lnk+title+"</div>"; //If no sub tiers for this branch then no arrow expand required
}else{
exp="<span style='cursor:pointer' onclick=\"ExpandTree('"+id+"')\">"+title+"<span class='aopen' id='img_"+id+"'></span></span>"; //Has sub tiers to show when requested
toHTML+="<div>"+ind+lnk+exp+"</div>"; //Show sub tier with expand option
toHTML+=display_tree_index(menu["items"][indexid]["id"],menu,name,tier,edit); //Set parent id to id and loop back on itself until all branches are rendered
}
}
if(parent>0){
toHTML+="</div>";
}
}
return toHTML;
}

////

function tdscs(rcb,scs){
var i,sc,l,l1,chkd,id,scats=[],tree_data={"items":[],"parents":[]};
if(scs.length>0){
scats=scs.split(","); //So we can tick the previous selections
l1=scats.length;
}else{
l1=0;
}
tree_data["items"].length=0;
tree_data["items"][0]={"titleid":"scstitle","sortid":"scssort","type":rcb,"oids":[]}; //Tree settings always in entry zero
l=subcats.length;
for(sc=0;sc<l;sc++){
chkd="";
for(i=0;i<l1;i++){
if(subcats[sc]["id"]==scats[i]){ //Finding the selected categories to set the check state
chkd=" checked";
tree_data["items"][0]["oids"].push(subcats[sc]["id"]); //Stores branches to open so all selections are visible
break;
}
}
tree_data["items"][sc+1]={"id":subcats[sc]["id"],"parentid":subcats[sc]["parentid"],"title":subcats[sc]["name"],"iqty":subcats[sc]["xitems"].length,"sort":subcats[sc]["sort"],"chkd":chkd}; //Transfers data to tree formatting
}
l=tree_data["items"].length;
for(i=1;i<l;i++){
id=tree_data["items"][i]["parentid"];
if(!tree_data["parents"][id]){ //Check if field exists
tree_data["parents"][id]=[i]; //Store first index
}else{
tree_data["parents"][id].push(i); //Add remaining indexes
}
}
return tree_data;
}

////

function EditTree(parentid,id,titleid,title,sortid,sort){
document.getElementById("parentid").value=parentid;
id=id.split("-");
document.getElementById("id").value=id["0"];
document.getElementById(titleid).value=unfilter(decodeURIComponent(title)); //We need to decode and then unfilter back to characters
document.getElementById("addundername").value=document.getElementById(titleid).value;
if(isNaN(parseInt(sort))===true){ //Checks if sort field is a valid number because we only use numbers to sort as it is easier to do so
sort=0;
}
document.getElementById(sortid).value=parseInt(sort);
}

////

function ExpandTree(obj){
if(!open_obj[obj]){
open_obj[obj]=false; //Set open status to false/close by default
}
if(open_obj[obj]===true){ //If open, close it
document.getElementById("div_"+obj).style.display="none";
document.getElementById("img_"+obj).className="aopen";
open_obj[obj]=false; //Set open status to close
}else{
document.getElementById("div_"+obj).style.display="block";
document.getElementById("img_"+obj).className="aclose";
open_obj[obj]=true; //Set open status to open
}
}

////

function reopen_tree(tree_data,titleid,oid,cats,cnt){ //Automatically opens the tree to the defined position(s)
try{
var i,l;
l=tree_data["items"].length;
for(i=1;i<l;i++){ //Starts at 1 since entry 0 is for settings
if(tree_data["items"][i]["id"]==oid&&tree_data["items"][i]["parentid"]>0){
cats[cnt]=tree_data["items"][i]["parentid"]+"-"+titleid; //Add unique tree branch id to array
cnt++;
//If invalid data such as the id and parentid are identical or there are broken/impossible tree branches this will throw an infinite loop error so we're using a try catch
return reopen_tree(tree_data,titleid,tree_data["items"][i]["parentid"],cats,cnt); //return loop back on itself with next oid for length of tree_data["items"]
}
}
if(cnt>0){
for(i=cats.length-1;i>-1;i--){ //Opens them one by one
document.getElementById("div_"+cats[i]).style.display="block"; //Show sub tiers
document.getElementById("img_"+cats[i]).className="aclose"; //Change class to close arrow
open_obj[cats[i]]=true; //Set status to open so it will close on the next click
}
}
}
catch(ex){
console.log("Invalid tree data: ("+oid+") "+ex); //Logs invalid tree data to the browser console. You should ensure that this does not happen by configuring your tree properly
}
}

////

function moveto(title){
document.getElementById("moveto").value=document.getElementById("id").value; //Stores the id to an invisible place which will become the parent id
document.getElementById("movetoname").value=document.getElementById(title).value;
window.top.window.msg(1,"MOVE TO category saved.<br>Select the category to move and click MOVE.");
}

function movesubcat(frm){
//We first need to check that the branch move is valid before making any changes to existing data
var parentid,id,brkn;
brkn=false; //Validation checks
parentid=parseInt(document.getElementById("moveto").value);
id=parseInt(document.getElementById("id").value);
brkn=broken_tree(parentid,id); //Returns whether this action would break the tree branch or not
if(brkn===false){
ajax_form("puw",frm,"moved","","JPOST","manage/updated","manage/updated");
}
}

function broken_tree(pid,id){ //Checks to see if moving the branch will cause empty spaces which would result in hidden unreachable branches
if(pid===id){
window.top.window.msg(2,"Warning: You can not move a category under itself.<br>Please re-select your choices and try again.");
return true; //You can't move it to its own branch
}else{
var i,l;
l=subcats.length;
for(i=0;i<l;i++){
if(subcats[i]["id"]==pid){
if(subcats[i]["parentid"]==id){
window.top.window.msg(0,"Warning: You can not break this branch by moving<br>this category under one of its own branches.");
return true; //Moving to the selected location would cause invalid branches
}else{
pid=subcats[i]["parentid"]; //On to check next parentid until we get back to the root
if(pid==0){
return false; //We're back at the root level and moving this branch is allowed
}else{
i=-1; //Start the loop from the beginning
}
}
}
}
}
return false; //Moving this branch is allowed
}

////

function removesubcat(frm){
//We first need to check that the branch to be deleted is ok to do so before making any changes to existing data
var parentid,id,brkn;
brkn=false; //Validation checks
parentid=parseInt(document.getElementById("parentid").value);
id=parseInt(document.getElementById("id").value);
brkn=deletecategory(parentid,id); //Returns whether this action would break the tree branch or not
if(brkn===false){
ajax_form("puw",frm,"deleted","","JPOST","manage/updated","manage/updated");
}
}

function deletecategory(parentid,id){ //Checks to see if deleting the category won't break any branches
var i,l,mesg,sc,brkn,tms,sbs,cnt,temp_catitems=[];
mesg="";
oids.length=0;
temp_catitems.length=0;
tms=false;
sbs=false;
cnt=-1;
l=subcats.length;
for(i=0;i<l;i++){
if(id!=subcats[i]["id"]){
cnt++;
temp_catitems[cnt]=subcats[i]; //Temporarily transfers subcats array, one by one, in to another array when it is not the category in question to be removed 
if(subcats[i]["parentid"]==parentid){
oids[0]=subcats[i]["id"]; //Saves the id so it can re-open the tree back to the same place after the changes
}
}else{
if(subcats[i]["qty"]>0||subcats[i]["xitems"].length>0){
tms=true; //Has items linked with it so it can't be removed yet
mesg+="Warning:<br>You must remove all items linked to<br>a category before you can delete it.<br>";
}
for(sc=0;sc<l;sc++){ //Loop through all subcats to see if the id we want to remove is a parentid of another branch
if(subcats[sc]["parentid"]==subcats[i]["id"]){
sbs=true; //The id of the category we are trying to delete is also a parentid on another branch so can not be removed
mesg+="Warning:<br>You must remove all sub categories<br>under this category before you can delete it.";
break;
}
}
if(sbs===true||tms===true){ //If either has items or more branches under it then break the loop early
break;
}else{
oids.push(subcats[i]["parentid"]); //Store all the id's so we can re-open the tree back to the same place
}
}
}
if(tms===true||sbs===true){ 
brkn=true; //If either has items linked with it or more branches under it then deleting would cause a break so can't be removed yet
oids.length=0; //Clear re-open ids because nothing changed
window.top.window.msg(0,mesg); //Show warning message
}else{
brkn=false;
subcats=temp_catitems; //Updates subcats without selected delete category
}
return brkn;
}

////

function msg(typ,mesg){ //Shows pop-up progress message
if(mesg.length>0){
var oHTML,d=mesg.length*150+1000; //Set auto close timer relative to length of message
clearTimeout(mt); //Clear timer so they are not stacked
if(typ==1){ //Good message
oHTML="<span style='display:block;padding:5px;' class='gbg aleft'><font class='tf'>"+mesg+"</font></span>";
}else{ //Warning message
oHTML="<span style='display:block;padding:5px;' class='rbg aleft'><font class='tf'>"+mesg+"</font></span>";
}
document.getElementById("msgbox").innerHTML=oHTML; //Fill msgbox id with message
document.getElementById("msgbox").style.display="block"; //Show
mt=setTimeout(function(){
document.getElementById("msgbox").style.display="none"; //Hide
},d); //Set close timer
}
}

////

function closePUW(){
document.getElementById("mainframe").style.display="block"; //Shows main screen again
document.getElementById("puw").style.display="none"; //Closes the pop up window which is not actually a window
}

////

function linkeditems(a,sort_chngd){
	//console.log("linkeditems");
	var l,i,n;
nxk=[]; //Makes sure it is an array and not a string
nxk.length=0; //Clears array
n=-1; //Index counter
l=items.length;
for(i=0;i<l;i++){
if(items[i]["mc"]===""||items[i]["scs"]===""||items[i]["scs"]==0||a==="all"){ //Check for blank entries
n++;
nxk[n]=i; //Stores all the index numbers that match the criteria above. We don't use .push() unless it's convenient to do so because it is slightly slower
}
}
temp_join(result,sort_chngd,nxk);
}

////

function recount_main_cats(result){ //Resets items main category counters
	//console.log("recount_main_cats");
var i,l,key,keys=[];
main_sub=true; //Main categories are dominant
keys=get_keys(maincats);
l=keys.length;
for(key=0;key<l;key++){ //Resets all maincats[] quantities to zero for counting
maincats[keys[key]]["qty"]=0;
maincats[keys[key]]["xitems"].length=0;
}
l=items.length;
for(i=0;i<l;i++){ //Counts the main category matches in array items[]
if(maincats[items[i]["mc"]]){
maincats[items[i]["mc"]]["qty"]++;
}
}
main_cats(result); //Show main categories with reset counters
}

////

function c_call_back(result){ //Function to perform when the pop-up page is closed to update the previous page
if(litems==="new"||litems==="all"||litems==="search"){ //We need to update the categories with the new selections and counters
sub_cats_cnt_xitems(); //Recalculate matching sub category items based on new main category selection
sub_cats_2tiers(result); //Render on screen sub categories
}
if(main_sub===true){
recount_main_cats(result); //Restores the maincats counters and updates page accordingly
}else{
main_cats_cnt_xitems(result,false); ////Counts how many times the maincats id appears in the items array and stores all the indexes
}
//Show the revised results based on category changes that may have happened
if(litems==="search"){ //Search? We need to know what feature was used in order to return to it
temp_join(result,true,""); //Show the same search results with revised data
}else if(litems==="main"||litems==="sub"){ //Category selections
hl_main(result,"reselect",sel_main_cat); //Reselect main category choice and show results which also updates sub cats menu
}else if(litems==="new"||litems==="all"){ //The show new or all items feature
linkeditems(litems,false);
}
closePUW();
}