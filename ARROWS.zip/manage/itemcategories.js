/*Copyright Aidan Woodrow aDesignHost.co.uk 2020. All rights reserved. WARNING: This line must not be removed.*/
var frm="linkitems",treeid="manageitemcategories",treename="scs"; //Do not change "scs"
//Template
var oHTML="<div><a id='xpuw' class='close xblk' href='#' onclick=\"c_call_back('"+result+"');\" title='Close'></a></div>";
oHTML+="<div><a class='adh' href=\"http://adesignhost.co.uk?ref=arrows\">Designed and Developed by Aidan Woodrow</a></div>";
oHTML+="<div style='max-height:700px;overflow-y:auto'>";
oHTML+="<div class='treeblk'>This tool is intended for use as an administrator and not an end user live production feature.</div>";
oHTML+="<div><form name='"+frm+"' id='"+frm+"'>";
oHTML+="<div class='fw' id='"+treeid+"'></div>";
oHTML+="</form></div>";
oHTML+="<div><a class='btngreen' onclick=\"ajax_form('puw','"+frm+"','updatelinked','','JPOST','manage/updated','manage/updated');\">SAVE LINKED CATEGORIES</a></div>";
oHTML+="<div id='item"+treeid+"'></div>";
oHTML+="</div>";
oHTML+="<div><a class='adh' href=\"http://adesignhost.co.uk?ref=arrows\">Copyright &#xa9; 2020 aDesignHost. All rights reserved</a></div>";
document.getElementById("puw").innerHTML=oHTML;
var ix=j["ix"];
var tree_data=tdscs("checkbox",items[ix]["scs"]); //Ticks all previously selected tree options. First option radio (single select) or checkbox (multi select). Next value: ID's of all checked boxes
var i,l1,id,chkd,key,keys=[],v=[];
v.length=0;
i=0;
v[i]={"name":"xid","value":ix,"options":"","type":"hidden"};
i++;
v[i]={"name":"id","value":items[ix]["id"],"options":"","type":"hidden"};
keys=get_keys(maincats);
l1=keys.length;
for(key=0;key<l1;key++){
id=keys[key];
if(id==items[ix]["mc"]){ //If found matching maincat set check state to checked 
chkd="checked";
}else{
chkd=""; //Not checked
}
i++;
v[i]={"name":"maincat","value":id,"options":maincats[id]["mc"]+"<br>","type":"radio","chkd":chkd,"class":"treeblk"}; //maincats array for the form
}
i++;
v[i]={"name":treename,"value":"","options":(tree_data),"edit":false,"type":"tree","class":"fw treeblk","tip":"Your Selections"}; //tree data for the form
displayform(treeid,v); //Show whole v form, including tree in id=treeid
cats.length=0;
catscnt=0;
l1=tree_data["items"][0]["oids"].length;
for(var oid=0;oid<l1;oid++){
reopen_tree(tree_data,treename,tree_data["items"][0]["oids"][oid],cats,catscnt); //Open tree to show all linked categories
}
temp_split(result+"_temp"); //Store template and values to insert if not already used/stored
//Show the item in question for reference
oHTML="";
l1=tempsplit.length-1; //Using l1 as the array count to ensure the fastest method
for(i=0;i<l1;i++){ //Minus 1 because the final segment will not have a value to insert within it
oHTML+=tempsplit[i]+items[ix][flds[i]]; //flds[i] name from the template must match the stored array field name
}
oHTML+=tempsplit[i]; //Tag on the final segment of the template which won't have a field to insert
document.getElementById("item"+treeid).innerHTML=oHTML; //Print complete html code to page within corresponding ID