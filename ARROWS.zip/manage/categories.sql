CREATE TABLE IF NOT EXISTS `subcategories` (
  `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `parentid` int(10) UNSIGNED NOT NULL DEFAULT '0',
  `name` varchar(50) NOT NULL DEFAULT '',
  `sort` decimal(7,3) NOT NULL DEFAULT '0.000',
  PRIMARY KEY (`id`)
) DEFAULT CHARSET=utf8;