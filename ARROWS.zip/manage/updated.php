<?php
/*Copyright Aidan Woodrow aDesignHost.co.uk 2021. All rights reserved. WARNING: This line must not be removed.*/
//Collect post data
ob_start();
$func=isset($_POST["func"])?$_POST["func"]:"";
$id=isset($_POST["id"])?strval($_POST["id"]):"0";
$parentid=isset($_POST["parentid"])?strval(intval($_POST["parentid"])):"0";
$parentname=isset($_POST["movetoname"])?filter($_POST["movetoname"]):""; //filter to prevent corrupt characters
$moveto=isset($_POST["moveto"])?strval(intval($_POST["moveto"])):"0";
$addu=isset($_POST["addundername"])?filter($_POST["addundername"]):""; //filter to prevent corrupt characters
$category=isset($_POST["scstitle"])?filter($_POST["scstitle"]):"Unknown"; //filter to prevent corrupt characters otherwise when you retrieve it from a database it will corrupt the code
if($category===""){$category="Blank";}
$sortorder=isset($_POST["scssort"])?strval(intval($_POST["scssort"])):"0"; //Numbers only accepted

$result=array("func"=>"","status"=>0,"id"=>0,"parentid"=>0,"name"=>"","sort"=>""); //Set a blank array with status set to zero
//Perform database functions and return success status string so the page can be updated accordingly
if($func=="added"){
$result=addedcategory($func,$parentid,$id,$category,$sortorder,$addu);
}elseif($id>0&&$func=="edited"){
$result=editedcategory($func,$id,$parentid,$category,$sortorder);
}elseif($id>0&&$func=="deleted"){
$result=deletecategory($func,$id,$parentid);
}elseif($id>0&&$func=="moved"){
$result=movecategory($func,$id,$moveto,$parentname);
}elseif($func=="updatelinked"){
$result=updatelinked($func,$id);
}

ob_clean(); //Makes sure any previously compiled data to output to the browser is cleared because we only want the j string
header("Content-Type:application/json");
echo json_encode($result); //Returns JSON array only to by picked up by the j[] array which is then used to perform JS

////

function filter($s){ //Code friendly. Prevents corrupt data. Always encode troublesome characters before saving to a database etc as it might not be possible afterwards depending on the retrievable method
$pat=array("/%/","/</","/>/","/\(/","/\)/","/\:/","/\"/","/\'/","/\//"); //some of these have to be \ escaped
$rep=array("&#37;","&#60;","&#62;","&#40;","&#41;","&#58;","&#34;","&#39;","&#47;");
return preg_replace($pat,$rep,$s);
}

////

function editedcategory($func,$id,$parentid,$category,$sortorder){
//$dbi=dbi_connect(""); //You need to add your own code to connect and update your database here
//$status=queryi($dbi,"update demo_cats set name='".$category."',sort='".$sortorder."' where id='".$id."'"); //where queryi is a function that performs database tasks
$status=true; //Hard wiring status to true so things work but you should retrieve this when performing the database update
return array("func"=>$func,"status"=>$status,"id"=>$id,"parentid"=>$parentid,"name"=>$category,"sort"=>$sortorder);
}

////

function addedcategory($func,$pid,$id,$category,$sortorder,$parentname){
/*
$dbi=dbi_connect(""); //You need to add your own code to connect and update your database here
//insert new category in to database. You must have an auto increment 'id' field in this table too
$q="insert into demo_cats(parentid,name,sort)VALUES('".$id."','".$category."','".$sortorder."')";
queryi($dbi,$q);
//retrieve from database new entry so we can verify it went in ok and obtain the unique auto increment id number at the same time
$q=queryi($dbi,"SELECT id FROM demo_cats where parentid='".$id."' and name='".$category."' and sort='".$sortorder."' order by id desc limit 1");
$r=mysqli_fetch_array($q);
if($r){
$status=true; //everything went in ok
$nid=$r["id"]; //new unique id number
}else{
$status=false; //something went wrong
$nid=-1;
}
*/
//random data for demo only
$nid=rand($id+500,$id+1000); //id has to be unique so for the demo version only we are using a random number between 500 and 1000 higher then its parent id but if it produces 2 the same the code will fail
$status=true; //You can change this to false to see the outcome of that for the demo
return array("func"=>$func,"status"=>$status,"nid"=>$nid,"pid"=>$pid,"parentid"=>$id,"name"=>$category,"sort"=>$sortorder,"parentname"=>$parentname);
}

////

function movecategory($func,$id,$parentid,$parentname){
//$dbi=dbi_connect(""); //You need to add your own code to connect and update your database here
//$status=queryi($dbi,"update demo_cats set parentid='".$parentid."' where id='".$id."'");
$status=true; //If you change the status to false, therefore the database did not update, then it will return this and not update the JSON array either.
return array("func"=>$func,"status"=>$status,"id"=>$id,"parentid"=>$parentid,"parentname"=>$parentname);
}

////

function deletecategory($func,$id,$parentid){
//$dbi=dbi_connect(""); //You need to add your own code to connect and update your database here
//$q="delete from demo_cats where id='".$id."'";
//$status=queryi($dbi,"delete from demo_cats where id='".$id."'";);
$status=true; //Correct status value is paramount so the database and JSON array are identical
return array("func"=>$func,"status"=>$status,"id"=>$id,"parentid"=>$parentid);
}

////

function updatelinked($func,$id){
//Perform database functions and return success status string so the page can be updated accordingly
$xid=isset($_POST["xid"])?$_POST["xid"]:"0";
$mc=isset($_POST["maincat"])?$_POST["maincat"]:"0";
$scs=isset($_POST["scs"])?$_POST["scs"]:"0";
$status=true; //this should only be true if the database updated correctly
//$dbi=dbi_connect(""); //You need to add your own code to connect and update your database here
//$status=queryi($dbi,"update items set maincat='".$mc."',sub_cats='".$scs."' where id='".$id."'");
return array("func"=>$func,"status"=>$status,"xid"=>$xid,"mc"=>$mc,"scs"=>$scs);
}

////

function queryi($dbi,$q){
$q=mb_convert_encoding($q,"UTF-8","UTF-8");
$r=@mysqli_query($dbi,$q);
return $r; //true or false
}
?>