/*Copyright Aidan Woodrow aDesignHost.co.uk 2020. All rights reserved. WARNING: This line must not be removed.*/
if(j){ //Check if return JSON string exists
func=j["func"];
}else{
func="";
}
//Template
var frm="editsubcats",treeid="managescs",treename="scs"; //Do not change these values
var titleid="scstitle",sortid="scssort",root="0-"+treename; //Do not change these values
var oHTML="<div><a id='xpuw' class='close xblk' href='#' onclick=\"scs_call_back('"+result+"');\" title='Close'></a></div>";
oHTML+="<div><a class='adh' href=\"https://adesignhost.co.uk?ref=arrows\">Designed and Developed by Aidan Woodrow</a></div>";
oHTML+="<div style='max-height:700px;overflow-y:auto'>";
oHTML+="<div class='treeblk'>This tool is intended for use as an administrator and not an end user live production feature.<br>There is no limit to the number of branches you can create.<br>Although note that only 2 Tiers will be visible with the ARROWS tool.</div>";
oHTML+="<div><form name='"+frm+"' id='"+frm+"'>";
oHTML+="<div class='fw' id='"+treeid+"'></div>";
oHTML+="</form></div>";
oHTML+="<div class='treeblk'>To move a category select the category that you want to move it to and click 'SAVE TO'<br>Then select the category you want to move and click 'MOVE'<br>All its sub categories will move too and linked items will remain unchanged.</div>";
oHTML+="<div class='fw treeblk' style='display:inline;'><a class='btngreen' onclick=\"ajax_form('puw','"+frm+"','added','','JPOST','manage/updated','manage/updated');\">ADD</a>";
oHTML+="<a class='btngreen' onclick=\"ajax_form('puw','"+frm+"','edited','','JPOST','manage/updated','manage/updated');\">EDIT</a>";
oHTML+="<a class='btngreen' onclick=\"moveto('"+titleid+"');\">SAVE TO</a>";
oHTML+="<a class='btngreen' onclick=\"movesubcat('"+frm+"');\">MOVE</a>";
oHTML+="<a class='btnred' onclick=\"removesubcat('"+frm+"');\">REMOVE</a></div>";
oHTML+="</div>";
oHTML+="<div><a class='adh' href=\"https://adesignhost.co.uk?ref=arrows\">Copyright &#xa9; 2021 aDesignHost. All rights reserved</a></div>";
document.getElementById("puw").innerHTML=oHTML;
var chkd="checked",mt,mtn,addu,id,pid;
mt="0";
mtn="";
addu="";
pid=0;
id=0;
if(func==="added"){
pid=j["pid"].toString();
addu=j["parentname"]; //Storing the add under name for reference
mtn=j["parentname"]; //Storing the move to name for reference
id=j["parentid"].toString(); //Restoring the add to id so you can add more to the same place without having to select it again and again
chkd=id; //Saving the current checked item to restore it
}else if(func==="edited"){
id=j["id"].toString();
chkd=id;
addu=j["name"];
}else if(func==="moved"){
mtn=j["parentname"]; //Storing the move to name for reference
mt=j["parentid"].toString(); //Restoring the move to id so you can move more to the same place without having to select it again and again
chkd=mt; //Saving the current checked item to restore it
}
var v=[],tree_data=tdscs("radio",chkd); //Populates the array with sub categories and ticks the entry in chkd
if(chkd!=="checked"){
chkd=""; //If a previous selection is being used then we use it otherwise we check/tick the ROOT option by default
}
//Configure tree data
v.length=0;
v[0]={"name":treename,"value":(titleid+","+sortid+","+root),"options":"ROOT (SORT)","edit":true,"chkd":chkd,"type":"radio","class":"treeblk","tip":"ROOT"};
v[1]={"name":treename,"value":"","options":(tree_data),"edit":true,"type":"tree","class":"treeblk","tip":"Select Sub-Category"};
v[2]={"name":titleid,"value":"","max":"50","type":"text","class":"boxlong","tip":"Enter Category"};
v[3]={"name":sortid,"value":"0","max":"8","type":"text","class":"boxshort","tip":"Enter Sort Order Number  (Decimal Places Accepted)"};
v[4]={"name":"parentid","value":pid,"max":"readonly","type":"hidden","class":"boxshort","tip":"Parent ID (Read only)"};
v[5]={"name":"id","value":id,"max":"readonly","type":"hidden","class":"boxshort","tip":"ID (Read only)"};
v[6]={"name":"addundername","value":addu,"max":"readonly","type":"text","class":"boxlong","tip":"Add Under (For Reference)"};
v[7]={"name":"moveto","value":mt,"max":"readonly","type":"hidden","class":"boxshort","tip":"Move To (Read only)"};
v[8]={"name":"movetoname","value":mtn,"max":"readonly","type":"text","class":"boxlong","tip":"Move To (For Reference)"};
displayform(treeid,v); //Show whole v form, including tree in id=treeid
if(oids.length>0){
reopen_tree(tree_data,treename,oids[0],cats,catscnt); //Re-open tree to previous most relevant position
}
function scs_call_back(result){ //Function to perform when the pop-up page is closed to update the previous page
sub_cats_2tiers(result); //Refresh sub categories on original page
closePUW();
}