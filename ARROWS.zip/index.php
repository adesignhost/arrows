<!--Copyright Aidan Woodrow aDesignHost.co.uk 2021. All rights reserved. WARNING: This line must not be removed-->
<!DOCTYPE HTML>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="description" content="ARROWS, the fastest JavaScript 100% client side navigation filter. The speed is gained by using the server and database less and client side resources more. Versatile Menu Content Filter with Search Facility">
<meta name="keywords" content="ARROWS, JavaScript tool, client side, filter, navigation, menu, tools, UI, Simple, Unbloated, Reliable, Fast, Efficient, Redesignable, Small">
<meta name="viewport" content="width=device-width, initial-scale=1"> <!--Designed for use with Desktop, laptop, tablet etc conventional screen sizes but could be modified for other devices-->
<link rel="icon" href="favicon.png" type="image/png">
<title>ARROWS filter</title>
<?php
$site=strtolower($_SERVER['HTTP_HOST']);
if($site==="localhost"){ //If off-line localhost server use none minified versions
?>
<!--css includes for using off-line-->
<link rel="stylesheet" type="text/css" media="all" href="arrows/arrows_filter.css"> <!--All page styling-->
	<link rel="stylesheet" type="text/css" media="all" href="manage/arrows_categories.css"> <!--All manage page styling-->
<?php
}else{
?>
<!--Minified css include you should use in production versions on-line-->
<link rel="stylesheet" type="text/css" media="all" href="demo/arrows_demo_filter.min.css"> <!--Production front end style but excludes manage styling-->
<?php
}
?>
</head>
<body class="bdy">
<?php
if($site==="localhost"){ //If off-line localhost server use none minified versions
?>
<script src="arrows/arrows_filter.js"></script> <!--Production front end functions-->
	<script src="demo/arrows_demo.js"></script> <!--Functions you won't need for your production code-->
	<script src="manage/arrows_functions.js" async></script> <!--Back end management functions that should remain off-line-->
<?php
}else{
?>
<!--Minified js include you should use in production versions on-line-->
<script src="demo/arrows_demo_filter.min.js"></script> <!--Production front end functions only. Excludes demo and manage functions-->
<?php
}
?>
<main>
<table class="center vatop">
<tr><td><a class="adesignhost" href="https://adesignhost.co.uk?main=digital_shop">Powered by: aDesignHost | Visit Shop</a></td></tr>
<tr><td><table id="mainframe">
<?php
$func=isset($_GET['func'])?$_GET['func']:"randomdata"; //Picks up the selected function for data sources. Defaults to randomdata
include("arrows/arrows_results_templates.html"); //This is the template with the arrows tags that must match the items[] array field names
include("demo/arrows_demo_filter.php"); //Retrieves the data, stores and then displays as per user selections
//include("arrows/arrows_example_filter.php"); //Same example as above but one that will look more like your live version
?>
</table></td></tr>
<tr><td><a class="adesignhost" href="https://adesignhost.co.uk">Copyright &#xa9; 2020-<?php echo gmdate('Y')?> aDesignHost. All rights reserved. Designed and Developed by Aidan Woodrow</a></td></tr>
</table>
</main>
<div><div id="msgbox"></div><div id="puw"></div></div>
</body>
</html>
<!--If you get a 500 server error it will be due to the .htaccess file. The following Apache modules are used but if they are enabled, especially with off-line localhost servers, then you may have to disable them. If this doesn't solve your off-line and/or on-line issue then delete the .htaccess file until you find a solution.
deflate_module (compressing)
expires_module (caching)
You can check if they are working on-line by visiting gtmetrix.com and test the page
All common modules should already be enabled when using on-line servers-->