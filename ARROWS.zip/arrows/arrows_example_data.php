<?php
/*Copyright Aidan Woodrow aDesignHost.co.uk 2021. All rights reserved. WARNING: This line must not be removed.*/
//$maincats=[]; //we are using JS instead so they are defined in arrows_example_filter instead of in here
//$subcats=[]; //we are using JS instead so they are defined in arrows_example_filter instead of in here
$items=[];
$allkw=[];

//3) ITEMS RESULTS
//You need to retrieve your items data from a database or other source. The following fields are required and must be in the correct format and valid.
//Just loop through them and transfer in to the $items[] array as is or processed first
for($i=0;$i<25;$i++){ //simple demo loop used here so there is some data to show
$id=strval($i); //unique id number (as a string) for each items from a database auto increment field for instance
$mc="M1"; //Main category id key. This is the string value which you have saved in your database maincat field. Not advisable to only use numbers here otherwise they may not be treated as keys and an array instead
$scs=strval("1,2,3"); //id number(s) (in a string so you can have several separated with commas) of the sub categories linked with this item
$title="title ".$i; //if you use the search facility with keywords this title will be used. If not you do not need to include it.
//these are here because they are in the template but of course will be your own data that match your own template
$added="added ".$i; 
$notes="notes ".$i;
$type="type ".$i;
$updated="updated ".$i;
$items[]=array("id"=>$id,"mc"=>$mc,"scs"=>$scs,"title"=>$title,"added"=>$added,"notes"=>$notes,"type"=>$type,"updated"=>$updated);

$kwords="keyword ".$i; //keywords if you are going to use them
$allkw[]=array("kwords"=>$kwords,"id"=>$id); //If you don't want a search facility then just // this line out and don't put anything in the $kwords above
}
?>