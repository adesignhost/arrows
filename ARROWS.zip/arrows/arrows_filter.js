/*Copyright Aidan Woodrow aDesignHost.co.uk 2021. All rights reserved. WARNING: This line must not be removed.*/
//Takes load off the server and reduces payload using exclusively client side and templates with caching
var result_temp,sel_main_cat,sort_type="fld_asc",ascdesc="asc",rpp=10,rpage=1,qw,manage,litems; //Global variables
var nxk=[],sel_sub_cats=[],tempsplit=[],flds=[],kwords=[],res=[],idsrch=[]; //Global arrays

////SORT OPTIONS
function sortoptions_template(t){
	//console.log("sortoptions_template");
var oHTML;
oHTML="<ul class='sidebar'><li class='heading gbg acenter'>"+t+"</li></ul>";
oHTML+="<ul class='sidebar' id='sort_options'></ul>";
document.getElementById("options").innerHTML+=oHTML; //You can style this template how ever you want. You just need to include the id part
}

////Sorting populate template with data
function sortoptions(r,s){
	//console.log("sortoptions");
var i,l,oHTML,temp,id;
oHTML=""; //Clear output render to screen first
l=s.length; //Although not noticeable in speed tests using JS if we use the count() function in PHP within the loop it takes multiple times longer to perform than storing the count in a variable first
//and then using that instead because it actually counts them where as JS does not. It actually just gets the index from the last entry which is quick each time but can be problematic if entries are missing because then it would be wrong.
for(i=0;i<l;i++){ //Loops through all sort options using l as the array count to ensure the fastest method
id=s[i]["id"];
temp="<li id='selected"+id+"' class='"+s[i]["class"]+"' onclick=\"hl_sort('"+r+"','"+s[i]["id"]+"','"+s[i]["AN"]+"');\">";
temp+="<div id='img"+id+"' class='arrowup'></div>"+(s[i]["option"])+"</li>";
oHTML+=temp; //Append output data
}
document.getElementById("sort_options").innerHTML=oHTML; //Print complete html code to page within corresponding ID
}

////MAIN CATEGORY OPTIONS
function main_category_template(t){
	//console.log("main_category_template");
var oHTML;
//This template can be any design. It just needs to include the id='maincategory'
oHTML="<ul class='sidebar'><li class='sidebar heading gbg acenter'>"+t+"</li></ul>";
oHTML+="<ul class='sidebar' id='main_category'></ul>";
document.getElementById("options").innerHTML+=oHTML; //Render on the page this template ready for inserting the data in to id 'maincategory'
}

////Main category populate template with data
function main_cats(r){ //maincats[] array, default sel_main_cat if none supplied
	//console.log("main_cats");
var i,l,clss,oHTML,key,keys=[];
oHTML=""; //Clear output render first
keys=get_keys(maincats); //Since we used keys for this one we have to loop through them differently
l=keys.length; //Using l as the array count to ensure the fastest method
for(i=0;i<l;i++){
key=keys[i]; //Store key for multiple use
	if(maincats[key]["qty"]>0){ //Won't show option if no matches but you can remove this and its closing bracket and show them never-the-less if you wish
if(key==sel_main_cat){
clss="t1sel";
}else{
clss="t1";
}
oHTML+="<li class='"+clss+"' id='main_cat_"+key+"selected' onclick=\"hl_main('"+r+"','','"+key+"');\">";
oHTML+="<div class='bq'>"+maincats[key]["qty"]+"</div>"+(maincats[key]["mc"])+"</li>";
	}
}
document.getElementById("main_category").innerHTML=oHTML; //Show complete html code within corresponding ID
}

////

function show_main_cats(r){
	//console.log("show_main_cats");
var dmc="",i,l,key,keys=[];
main_sub=true; //Main categories are dominant
keys=get_keys(maincats); //Since we used keys for this one we have to loop through them differently
l=keys.length;
for(key=0;key<l;key++){ //Resets all maincats[] quantities to zero for counting
maincats[keys[key]]["qty"]=0;
maincats[keys[key]]["xitems"].length=0;
}
l=items.length;
for(i=0;i<l;i++){ //Counts the main category matches in array items[]
if(maincats[items[i]["mc"]]){
maincats[items[i]["mc"]]["qty"]++;
dmc=items[i]["mc"]; //set default selection
}
}
sel_main_cat="";
main_cats(r); //Show main categories with reset counters
if(document.getElementById("sub_cats")){
document.getElementById("sub_cats").innerHTML=""; //Clears sub categories
document.getElementById("result_count").innerHTML="";
document.getElementById("show_results").innerHTML="";
}
if(dmc!==""){
hl_main(r,"",dmc);
}
}

////

function main_cats_cnt_xitems(r,sc){
	//console.log("main_cats_cnt_xitems");
var i,ii,l,l1,l2,key,keys=[],xi=[],mxi=[],kx;
keys=get_keys(maincats); //Since we used keys for this one we have to loop through them differently
l=keys.length;
for(key=0;key<l;key++){ 
maincats[keys[key]]["qty"]=0; //Stores quantity of matches
maincats[keys[key]]["xitems"].length=0; //Stores items indexes as a standard array
}
l1=sel_sub_cats.length;
for(i=0;i<l1;i++){ //Loop through selected sub categories
xi=subcats[sel_sub_cats[i]]["xitems"]; //Transfers unique sorted sub category items indexes
l2=xi.length;
for(ii=0;ii<l2;ii++){ //Loops through items indexes for each sub category
kx=items[xi[ii]]["mc"]; //Stores the maincats key
if(maincats[kx]){ //Check if a valid key
maincats[kx]["xitems"][xi[ii]]=1; //Stores items indexes as a key so they become unique and sorted at the same time
}
}
}
for(key=0;key<l;key++){
mxi=get_keys(maincats[keys[key]]["xitems"]); //Stores unique sorted items indexes
maincats[keys[key]]["qty"]=mxi.length; //Stores quantity of matches
maincats[keys[key]]["xitems"]=mxi; //Stores items indexes as a standard array
}
if(sc===false){
main_cats(r); //Displays maincats[] options with revised quantity matches
}
}

////

function sub_category_template(t){
	//console.log("sub_category_template");
var oHTML="<ul class='sidebar'><li class='sidebar heading gbg acenter'>"+t+"</li></ul>";
oHTML+="<ul class='sidebar' id='sub_cats'></ul>";
document.getElementById("options").innerHTML+=oHTML;
}

////

//Adds a counter of all paired sub categories and items using the field specified and the prefix
function sub_cats_cnt_xitems(){ //Counts and collates items by index under each category. If items or subcats array are sorted the indexes will change so you need to perform this afterwards
	//console.log("sub_cats_cnt_xitems");
var l,l1,l2,i,ii,sc,qty,items_sub_cats;
l=subcats.length;
for(ii=0;ii<l;ii++){
qty=0;
subcats[ii]["xitems"].length=0;
l1=items.length;
for(i=0;i<l1;i++){
if(items[i]["mc"]==sel_main_cat||main_sub===false){ //Rather than account for a blank ["scs"] error it should be avoided at the very beginning of the error chain by saving it to the database/array with a value
items_sub_cats=items[i]["scs"].split(","); //If ["scs"] is empty this will error since you can't split nothing. Using link uncategorised allows you to add one but the insertion code should ensure it is not blank which is the original error
l2=items_sub_cats.length;
for(sc=0;sc<l2;sc++){
if(subcats[ii]["id"]==items_sub_cats[sc]){ //Count sub category and mc selection and items sub cat matches
subcats[ii]["xitems"][qty]=i; //Save i index values for any number of tiers
qty++;
break; //Can only have unique categories in items scs so on to the next item
}
}
}
}
subcats[ii]["qty"]=qty; //Store category matches counter for any number of tiers
if(qty===0){
subcats[ii]["tf"]=""; //If the revised counters are zero the check state needs to be reset otherwise it can be left as is which means when you change the main cat the valid sub cats will be already selected
}
}
}

////

function cats_xsubs(){ //Collates tier 2 categories by index under each tier 1 category. If subcats[] array is sorted this function is performed afterwards
	//console.log("cats_xsubs");
var i,ii,x,l;
l=subcats.length;
for(ii=0;ii<l;ii++){ //Loop through subcats[]
x=-1;
subcats[ii]["xsubs"].length=0; //Clear sub indexes
if(subcats[ii]["parentid"]=="0"){ //Ensuring parentid = 0 prevents the tree having more than one branch so only 2 tiers maximum otherwise subsequent code could error
for(i=0;i<l;i++){ //Loop through subcats[]
if(subcats[ii]["id"]==subcats[i]["parentid"]){
x++;
subcats[ii]["xsubs"][x]=i; //Adds index value to the array. We do these things to spread the load and make the whole tool faster
}
}
}
}
}

////

////Sub category populate template with data
function sub_cats_2tiers(r){
	//console.log("sub_cats_2tiers");
var i,ii,l,l1,oHTML,temp,id,clss,sqty,icnt,qty,partemplate,xsubs; //We just define the variables we are using at the very beginning but not set them here
sel_sub_cats.length=0; //Resetting selected sub categories
oHTML="";
l=subcats.length;
for(i=0;i<l;i++){
if(subcats[i]["parentid"]=="0"){ //We process all the Tier 1 categories and then find the Tier 2 ones relating to it
sqty=Number(subcats[i]["qty"]); //Makes sure it is a number and not a string
if(sqty>0||subcats[i]["xsubs"].length>0){ //Shows first category tier if it has tier 2 branches or linked items
if(subcats[i]["tf"]===true){ //Re-procesing selected options. If the same sub category exists in the previous main selection it will remain checked
sel_sub_cats.push(i);
clss="t1sel"; //Tier 1 style is slightly different to Tier 2
}else{
clss="t1";
}
if(sqty===0){ //If no items itself but tier 2 categories
qty=""; //Choosing not to show counter if zero
if(rcbox==="single"||auto_sel_tier2===false||one_block_subs===true){ //If single select only then it is unselectable
clss="t1unsel"; //Has no linked items itself but has subs which might but sub categories are set to single select so it is made unselectable
}
}else{
qty=sqty;
}
id=subcats[i]["id"];
temp="<li class='"+clss+"' id='sub_cat_"+id+"selected' onclick=\"hl_sub_"+rcbox+"('"+r+"','"+i+"','"+id+"');\">"; //Radio single or Checkbox multi select on click event
temp+="<div class='bq' id='sub_cat_"+id+"qty'>"+qty+"</div>"+(unfilter(subcats[i]["name"]))+"</li>"; //Tag the final part which applies to both
partemplate=temp;
icnt=0; //Required to set here in case all categories are Tier 1 only because of the sqty+icnt below meaning icnt must be a valid number
if(subcats[i]["xsubs"].length>0){ //Checking if there are sub categories to show too
l1=subcats[i]["xsubs"].length;
for(ii=0;ii<l1;ii++){ //Loop through Tier 2 categories
xsubs=subcats[i]["xsubs"][ii];
if(Number(subcats[xsubs]["qty"])>0){ //Just checking they are not empty categories. If they are they will not be shown. Which means when new categories are added using the manage tree they won't show either
icnt++; //Counting Tier 2's
id=subcats[xsubs]["id"];
if(subcats[xsubs]["tf"]===true){
sel_sub_cats.push(xsubs);
clss="t2sel"; //Tier 2 style is slightly different to Tier 1
}else{
clss="t2";
}
temp="<li class='"+clss+"' id='sub_cat_"+id+"selected' onclick=\"hl_sub_"+rcbox+"('"+r+"','"+xsubs+"','"+id+"');\">"; //Radio single or Checkbox multi select on click event
temp+="<div class='bq' id='sub_cat_"+id+"qty'>"+subcats[xsubs]["qty"]+"</div>"+(unfilter(subcats[xsubs]["name"]))+"</li>";
partemplate+=temp;
}
}
}
if(sqty+icnt>0){ //If the Tier 1 has no items linked with it and none of its sub categories do either then it won't be listed. If it had none itself but subs that did it would be listed.
oHTML+=partemplate;
}
}
}
}
document.getElementById("sub_cats").innerHTML=oHTML; //Show processed subcats[]
}

////

function main_sub_results(r,frm,sc){ //main_sub=true
	//console.log("main_sub_results");
if(frm==="main"){
sub_cats_cnt_xitems(); //Recalculate matching sub category items based on new main category selection
sub_cats_2tiers(r); //Render on screen sub categories
if(sel_sub_cats.length>0){
temp_join(r,sc,""); //Shows the results. This is performed when a sub category is changed and main_sub=true
}else{
document.getElementById("result_count").innerHTML=""; //No results, so clears
document.getElementById("show_results").innerHTML=""; //Clears results awaiting sub category selection
}
}else{
temp_join(r,sc,""); //Shows the results. This is performed when a sub category is changed and main_sub=true
}
}

////

function sub_main_results(r,frm,sc){ //main_sub=false
	//console.log("sub_main_results");
if(frm==="sub"){
var prev_sel_main_cat=sel_main_cat; //Store previous selection to auto re-select after sub category option changes
main_cats_cnt_xitems(r,sc); //Process maincats[] matches against sub category changes
hl_main(r,"reselect",prev_sel_main_cat); //Restores main category selection
}else{
temp_join(r,sc,""); //Shows the results. This is performed when a main category is changed and main_sub=false
}
}

////

function temp_split(ts){
	//console.log("temp_split");
if(result_temp!==ts){ //Checks to see if template array has changed because we have saved one template so it doesn't waste time and resources splitting it again and again
	//console.log("temp_splitted");
var i,l,str=[];
result_temp=ts; //Save new template name 
tempsplit.length=0; //Clear previous data
flds.length=0; //Clear previous data
if(document.getElementById(ts)){ //Checks to see if template code exists/named correctly
tempsplit=document.getElementById(ts).innerHTML.split("«"); //Begins to split it in to useable parts
l=tempsplit.length-1; //Using l-1
for(i=0;i<l;i++){
str=tempsplit[i].split("»"); //Continues to split the template in to useable parts
tempsplit[i]=str[0]; //Store each piece
flds[i]=str[1]; //Store each arrows tag
}
}else{
console.log("Your code does not contain the specified '"+ts+"' template.");
}
}
}

////

function temp_join(r,sc,xids){
	//console.log("temp_join");
var l,l1,l2,l3,i,ii,iii,itoi,nxitems=[]; //Declare some variables
temp_split(r+"_temp"); //Go to process the results template if it isn't stored already
if(litems==="all"||litems==="new"){ //if we are dealing with the manage view all or new items
//skip this function
}else if(litems==="search"){ //means we are now dealing with the search facility
if(sc===true){ //If the sort order has been changed then we need to re-calibrate id's for new index numbers
if(xids===""||xids.length===0){ //If there are no existing selections for the search
xids=idsrch; //Transfer previous selections
}else{
idsrch=xids; //Store these selections which can then be transfered above next time around
}
nxitems.length=0; //Clear the array we use to log indexes
l=xids.length;
l1=items.length;
for(i=0;i<l;i++){
for(itoi=0;itoi<l1;itoi++){
if(items[itoi]["id"]==xids[i]){ //For the search we need to find the ID's so we can use the index numbers
nxitems[itoi]=1; //Saving as keys using the index prevents duplicates and sorts at the same time. Value is irrelevant
break; //break the loop and on to the next xids
}
}
}
nxk=get_keys(nxitems); //Create an array of all the unique keys in numerical order
}
}else if(main_sub===true){ //Main category dominance meaning select main category reconfigure sub categories
if(rcbox==="multi"&&and_subs===true){ //rcbox multi select must be set as well / true = where all tier 1/2 blocks contain matches with each other. false = or for all subcategories.
desel(); //Using the matching results we eliminate sub categories that no longer match the current selections
}else{
nxitems.length=0; //Clear the array we use to log indexes
l2=sel_sub_cats.length; //Selected sub categories
for(ii=0;ii<l2;ii++){ //Loop through selected sub categories
l3=subcats[sel_sub_cats[ii]]["xitems"].length;
for(iii=0;iii<l3;iii++){ //Loop through all subcats[] xitems
nxitems[subcats[sel_sub_cats[ii]]["xitems"][iii]]=1; //Using keynames prevents duplicates and automatically sorts them. Value is irrelevant because we are only using the indexes
}
}
nxk=get_keys(nxitems); //Create an array of all the unique keys in numerical order
}
}else{
if(maincats[sel_main_cat]){ //Making sure the stored selected main category is a valid option
nxk=maincats[sel_main_cat]["xitems"]; //Populate nxk array with already processed items index numbers
}else{
nxk=0; //No valid main category selection has been made yet
}
}
if(nxk.length>0){ //Has to be results to show
page_view_results(rpp,rpage); //Show filtered results in page form
}else{
document.getElementById("result_count").innerHTML=""; //No results, so clears counter display
document.getElementById("show_results").innerHTML="<div class='wh'>Select one main category and at least one sub category.</div>"; //No results, so clears
}
if(document.getElementById("show_results").style.display=="none"){
showhidecontent("show_results","morecontent"); //If the results is hidden because another facility was previously being used then make it visible
}
}

////

function page_view_results(pp,page){
	//console.log("page_view_results");
var mesg,i,l,oHTML,xi,nxi,minpp=10; //Minimum results per page
var rxpp=Math.max(pp,minpp);
var mtch=nxk.length;
var start,finish,bck,nxt;
var pages=Math.ceil(mtch/rxpp); //Maximum number of pages
pages=Math.max(1,pages); //1 pages minimum
page=Math.max(1,page); //1 page minimum
page=Math.min(page,pages); //Makes sure page is not greater than total pages
oHTML="";
rpp=rxpp; //Stores the results items per page so when the sort order is changed, for instance, it will return to the same value 
rpage=page; //Stores the results items page number so when the sort order is changed, for instance, it will return to the same page
if(mtch>minpp){ //Only if matches are greater than the show per page

oHTML+="<table class='fw'><tr><td><table class='center'><tr>";
oHTML+="<td><ul class='pvmenu'><li>&nbsp;SHOW&nbsp;<ul>";
finish=Math.min(minpp*5+1,mtch+minpp);
for(i=minpp;i<finish;i=i+minpp){ //Loop through per page options
if(i==pp){ //If current selection show highlighted
oHTML+="<li class='pvsel'>&nbsp;"+i+"&nbsp;Per&nbsp;Page&nbsp;</li>";
}else{
oHTML+="<li onclick=\"page_view_results("+i+","+page+");\">&nbsp;"+i+"&nbsp;Per&nbsp;Page&nbsp;</li>";
}
}
oHTML+="</ul></li></ul></td>";
bck=page-1;
if(bck>1){ //If back option takes you to page 2 or more
oHTML+="<td class='pv' onclick=\"page_view_results("+pp+","+bck+");\">&nbsp;<b>BACK</b>&nbsp;</td>";
}else if(bck===1){ //If back takes you to the first page
oHTML+="<td class='pv' onclick=\"page_view_results("+pp+",1);\">&nbsp;<b>FIRST</b>&nbsp;</td>";
}
start=Math.max(1,page-2); //minus 2 will show two pages to the left of the current page
finish=Math.min(pages,page+2); //plus 2 will show two pages to the right of the current page
for(i=start;i<=finish;i++){
if(i<page){
if(bck>1){
oHTML+="<td class='pv' onclick=\"page_view_results("+pp+","+i+");\">&nbsp;<b>"+i+"</b>&nbsp;</td>";
}
}else if(i===page){ //If page is this page show non-selectable number only
oHTML+="<td class='pvtxt pvsel'>&nbsp;"+page+"&nbsp;</td>";
}else if(page+1<pages){
oHTML+="<td class='pv' onclick=\"page_view_results("+pp+","+i+");\">&nbsp;<b>"+i+"</b>&nbsp;</td>";
}
}
nxt=page+1;
if(nxt<pages){
oHTML+="<td class='pv' onclick=\"page_view_results("+pp+","+nxt+");\">&nbsp;<b>NEXT</b>&nbsp;</td>";
}else if(page<pages){ //If next page is the last page
oHTML+="<td class='pv' onclick=\"page_view_results("+pp+","+pages+");\">&nbsp;<b>LAST</b>&nbsp;</td>";
}
oHTML+="<td><ul class='pvmenu'>";
oHTML+="<li>&nbsp;PAGE&nbsp;<ul>";
for(i=1;i<pages+1;i++){ //Loop through all page numbers and display in drop down box
if(i===page){ //If page is this page in the drop down box show as hled non-selectable
oHTML+="<li class='pvsel'>&nbsp;PAGE&nbsp;"+i+"&nbsp;</li>";
}else{
oHTML+="<li onclick=\"page_view_results("+pp+","+i+");\">&nbsp;PAGE&nbsp;"+i+"&nbsp;</li>";
}
}
oHTML+="</ul></li></ul></td>";
oHTML+="</tr></table></td></tr></table>";
}
//Set variables to utilise a single loop for both ascending and descending
	mesg="Showing 1";
start=(page-1)*rxpp; //start point
if(ascdesc.toLowerCase()==="desc"){
start-=(nxk.length-1); //Adjusted start point
finish=Math.min(start+pp,1); //Descending finish point
    if(mtch>1){ //Show results count if greater than 1
    mesg="Showing "+(mtch+start)+"-"+(mtch+finish-1)+" of "+mtch+" records";
    }
}else{
finish=Math.min(start+rxpp,mtch); //Ascending finish point
    if(mtch>1){
    mesg="Showing "+(start+1)+"-"+finish+" of "+mtch+" records";
	}
}
l=tempsplit.length-1; //Always minus 1
for(xi=start;xi<finish;xi++){ //Loop forwards and backwards using the same code
nxi=Math.abs(xi); //When descending only this is required to convert the negative number into the positive index because we don't sort anything backwards only loop through backwards

	if(manage===true){ //If manage is set to true add an option to each item to change the linked main and sub categories
	oHTML+="<div class='acenter'><a class='btngreen' onclick=\"j['ix']='"+nxk[nxi]+"';aj('manage/itemcategories');\">UPDATE LINKED CATEGORIES</a></div>";
	}

for(i=0;i<l;i++){
    if(items[nxk[nxi]][flds[i]]==null){ //Checks to see if the »arrows« tag in the template exists in the items[] array so it can display it
    console.log("Missing: "+flds[i]); //If not show in browser console window
    } //You should remove these 3 lines in the production version because it shouldn't be required
oHTML+=tempsplit[i]+items[nxk[nxi]][flds[i]]; //Build HTML code using template pieces and flds[] names which must match the items[] array field names
}
oHTML+=tempsplit[i]; //Tag on the final segment of the template which will not have a field to insert
}
document.getElementById("show_results").innerHTML=oHTML; //print complete html code to page within corresponding ID
	document.getElementById("result_count").innerHTML=mesg;
}

////

function search_template(r,h,t){ //Search drop down template
	//console.log("search_template");
var oHTML;
oHTML="<div onclick=\"ExpandHide('kws','queryword')\"><table class='search fw'><tr><td class='ct'></td><td class='acenter'>"+h+"</td><td class='ct'><span id='img_kws' class='arrowdown'></span></td></tr></table></div>";
oHTML+="<div style='display:none;' id='div_kws'>";
oHTML+="<div id='KeywordResults'></div>";
oHTML+="<div class='wh acenter'>Separate multiple words/phrases with a, comma<br><input type='text' size='50' maxlength='255' class='srchbox vlcorner sbg' name='queryword' id='queryword' tabindex='0' onkeyup=\"search_keywords('KeywordResults','"+r+"','"+t+"');\"></div>";
oHTML+="<div class='scroller acenter' id='title_results'></div>";
oHTML+="</div><br>";
document.getElementById("search_results").innerHTML=oHTML;
}

////

function filter(s){ //Code friendly. Prevents corrupt characters but you can add more to filter out completely rather than convert some characters
var enc={"(":"&#40;",")":"&#41;","%":"&#37;","<":"&#60;",">":"&#62;","\:":"&#58;","\"":"&#34;","\'":"&#39;","\/":"&#47;","\\":"&#92;"};
return s.replace(/[()%<>:\"\'\/\\]/g,function(str){return enc[str];}); //some of these have to be \ escaped
}

function unfilter(s){ //Converts corrupt characters back
var enc={"&#40;":"(","&#41;":")","&#37;":"%","&#60;":"<","&#62;":">","&#58;":"\:","&#34;":"\"","&#39;":"\'","&#47;":"\/","&#92;":"\\"};
return s.replace(/&#40;|&#41;|&#37;|&#60;|&#62;|&#58;|&#34;|&#39;|&#47;|&#92;/g,function(str){return enc[str];});
}

////

function keywords(k,msl){ //Processes, sorts, counts and stores all search keywords
	//console.log("keywords");
var i,ii,l,l1,l2,sp,temp_kwords,akw,qty,all_keywords=[],xtm=[],allkws=[];
if(k){ //Check if there are any
l=k.length;
akw=-1;
for(i=0;i<l;i++){
if(k[i]["kwords"]){
sp=k[i]["kwords"].toString(); //Makes any numbers a string so they can be processed the same
if(sp.length>0){ //Can split a single word without a comma but can't a blank string
temp_kwords=sp.split(","); //Create an array of keywords for that line
l1=temp_kwords.length;
for(ii=0;ii<l1;ii++){
	temp_kwords[ii]=trm(temp_kwords[ii]); //trim blank spaces front and back. Technically this should be performed in PHP when they were originally saved. If so this line could be removed
if(temp_kwords[ii].length>=msl){
akw++;
all_keywords[akw]={"kword":(temp_kwords[ii].toUpperCase()),"id":k[i]["id"]}; //Divide list of keywords in to a single word per row 
}
}
}
}
}
all_keywords=sortjsonfld(all_keywords,"kword","A"); //Sort keywords so we can compare matches of the same words
all_keywords[akw+1]={"kword":"nomorekeywords","id":0}; //Tagging on a final row because we are checking +1
qty=1; //First match
akw=0;
xtm[akw]={"ids":[]}; //Create blank array for first keyword
xtm[akw]["ids"][0]=all_keywords[0]["id"]; //Insert first linked items id
l2=all_keywords.length-1; //Minus 1 because we are comparing the next entry which must exist
for(i=0;i<l2;i++){
if(all_keywords[i]["kword"]===all_keywords[i+1]["kword"]){ //If keyword is the same as the next keyword add 1 to the counter
xtm[akw]["ids"][qty]=all_keywords[i+1]["id"]; //Add matching ids
qty++;
}else{
allkws[akw]={"kword":all_keywords[i]["kword"],"qty":qty,"iditems":xtm[akw]["ids"]}; //Store unique keyword, quantity it appears and an array of item indexes it matches with
qty=1; //Reset counter back to 1
akw++;
xtm[akw]={"ids":[]}; //Create blank array for next keyword
xtm[akw]["ids"][0]=all_keywords[i+1]["id"]; //Insert first linked items id
}
}
}
return allkws;
}

////

function search_keywords(obj,r,t){
	//console.log("search_keywords");
var queryword=trm(document.getElementById("queryword").value.toString()); //Remove preceding and trailing blank spaces from user search criteria
var qw1=queryword.replace(/ +/g,",").toUpperCase(); //Will also separate and search for phrase words
if(qw!==qw1&&qw1.length>0){ //We check if the user inputted search criteria has changed otherwise we won't perform any further code since any key press will bring us here
qw=qw1;
var oHTML,i,ii,l,l1,l2,str,ikws,kws,mtch,mtches,cnt,ls,lk,llen,si,idtotitle,itot,nxitems=[],itemids=[],keys=[];
llen=1;
mtch=0;
res.length=0;
nxitems.length=0;
lk=kwords.length;
l2=items.length;
str=qw.split(","); //Create an array of user search words
ls=str.length;
for(si=0;si<ls;si++){ //Loop through user input search criteria
l1=str[si].length; //Get the length of their search data
if(l1>=min_search_len){ //Length must be equal or greater than minimum search length
for(i=0;i<lk;i++){
kws=kwords[i]["kword"].split(" "); //Removes blank spaces and replaces with a comma to search for phrase words
ikws=kws.length;
for(ki=0;ki<ikws;ki++){
if(kws[ki].substr(0,l1)==str[si]){ //Matching against keywords reducing length to match the same as the user input data
l=kwords[i]["iditems"].length;
itemids.length=0; //Clear to re-use
for(ii=0;ii<l;ii++){
idtotitle=kwords[i]["iditems"][ii]; //Now matched we need to find the item using its id
for(itot=0;itot<l2;itot++){
if(items[itot]["id"]==idtotitle){ //id match
itemids[idtotitle]=1; //Value set to 1 is irrelevant because we are not using any values, just the indexes
if(!nxitems[idtotitle]){ //Check if key named entry exists
nxitems[idtotitle]=[]; //Creates empty array
nxitems[idtotitle]["title"]=items[itot][t]; //Saving title under keys using the index prevents duplicates and sorts at the same time
nxitems[idtotitle]["qty"]=-1; //Saving quantity count also as keys. We have to use minus figures because we are sorting them below by total matches and the function only sorts ascending
}else{
nxitems[idtotitle]["qty"]--; //Count total matches using minus figures
}
break; //Found the item so break the itot loop
}
}
}
keys=get_keys(itemids);
res[mtch]={"kword":kwords[i]["kword"],"qty":kwords[i]["qty"],"itemids":keys}; //Results
llen=Math.max(res[mtch]["kword"].length,llen); //Longest keyword length used to calculate results per row
mtch++; //Search found counter
}
}
}
}
}
if(qw.length>=min_search_len){ //Search string length must be at least the defined value
if(mtch===0){ //If no matches clear everything
document.getElementById(obj).innerHTML="<table class='rbg smfont main fw'><tr><td class='acenter'>Searched for: <b>"+(filter(qw))+"</b><br>(Sorry, no results found)</td></tr></table>";
document.getElementById("title_results").innerHTML="";
}else{
cnt=0;
oHTML="<table class='fw'>";
nxk=get_keys(nxitems); //Convert sorted unique keys to an array to show results
nxitems=sort_object(nxitems,"qty","N",false); //Sort a number-key object by the 'qty' field Numerically and transfer its key to field 'x' then remove its keys changing to a standard array so its sort order remains correct
l=nxitems.length;
for(i=0;i<l;i++){ //Show all matching keywords
cnt++;
oHTML+="<tr><td><a class='sr' onclick=\"kwords_show('"+r+"','"+nxitems[i]["k"]+"',0);\">"+nxitems[i]["title"]+"</a></td></tr>";
}
oHTML+="</table>";
document.getElementById("title_results").innerHTML=oHTML;
if(mtch===1){
mtches="<b>"+mtch+"</b> match";
}else{
mtches="<b>"+mtch+"</b> matches";
}
if(cnt>1){
cnt="<b>"+cnt+"</b> records";
}else{
cnt="<b>1</b> record";
}
oHTML="<table class='gbg smfont main fw'><tr><td>";
oHTML+="<div class='acenter'>Searched for: <b>"+(filter(qw))+"</b></div>";
oHTML+="<div class='acenter'>Found "+mtches+" pertaining to "+cnt+"</div>";
oHTML+="<div class='acenter'>(Select a KEYWORD or TITLE to view results)</div>";
oHTML+="</td></tr></table>";
oHTML+="<div id='pv'></div>";
document.getElementById(obj).innerHTML=oHTML;
page_view_search(llen,10,1,mtch,r,obj);
}
}else{
document.getElementById(obj).innerHTML="<table class='gbg smfont main fw'><tr><td class='acenter'>Please enter at least "+min_search_len+" characters.</td></tr></table>";
document.getElementById("title_results").innerHTML="";
}
}
}

////

function page_view_search(llen,spp,spage,mtch,r,obj){
	//console.log("page_view_search");
var minpp=10; //Minimum rows per page
var row=Math.floor(50/llen,0); //Calculates number of keywords that will fit on one row
row=Math.max(row,1); //Per row must be at least 1
row=Math.min(row,5); //Per row is limited to 5
if(mtch<row){
row=1; //If not at least 1 full row then default to 1 per row
}
var rxpp=Math.max(spp,minpp)*row; //Show per page multiplied by per row
var pages=Math.ceil(mtch/rxpp); //Maximum number of pages
pages=Math.max(1,pages); //Must be at least 1
spage=Math.max(1,spage); //Must be at least 1
spage=Math.min(spage,pages);
var start=(spage-1)*rxpp; //Start point based on page selection
var finish=Math.min(start+rxpp,mtch); //Crop final result to show so it doesn't exceed total results
var i,cnt=0,oHTML,str,bck,nxt;
oHTML="<table class='fw'>";
for(i=start;i<finish;i++){ //Displays all matched keywords from page start to page finish
if(cnt===0){ //Start new row
oHTML+="<tr>";
}
oHTML+="<td class='c"+row+"'><a class='sr' onclick=\"kwords_show('"+r+"',"+i+",1);\">"+res[i]["kword"]+" ("+res[i]["qty"]+")"+"</a></td>";
cnt++; //Count how many per row so far
if(cnt===row){
oHTML+="</tr>"; //End row within loop
cnt=0; //So a new row will start
}
}
if(cnt>0){ //If row closing tag wasn't performed because it was mid row and there were more than one row
for(cnt=cnt+1;cnt<=row;cnt++){
oHTML+="<td>&nbsp;</td>"; //Continue to end of row
}
oHTML+="</tr>"; //End row after loop
}
oHTML+="</table><br>";
if(mtch>minpp*row){ //If more than one page show page options
oHTML+="<table class='fw'><tr><td><table class='center'><tr>";
oHTML+="<td><ul class='pvmenu'><li>&nbsp;PER PAGE&nbsp;<ul>";
finish=Math.min(minpp*5+1,mtch/row+minpp);
for(i=minpp;i<finish;i=i+minpp){ //Loop through per page options
if(row>1){ //If per row is greater than 1
str=row+"x "+i+" Rows"; //Show per row x rows
}else{
str=i;
}
if(i===spp){ //If current selection show hled
oHTML+="<li class='pvsel'>&nbsp;"+str+"&nbsp;</li>";
}else{
oHTML+="<li onclick=\"page_view_search("+llen+","+i+","+spage+","+mtch+",'"+r+"','"+obj+"');\">&nbsp;"+str+"&nbsp;</li>";
}
}
oHTML+="</ul></li></ul></td>";
bck=spage-1;
if(bck>1){ //If back option takes you to page 2 or more
oHTML+="<td class='pv' onclick=\"page_view_search("+llen+","+spp+","+bck+","+mtch+",'"+r+"','"+obj+"');\">&nbsp;<b>BACK</b>&nbsp;</td>";
}else if(bck===1){ //If back takes you to the first page
oHTML+="<td class='pv' onclick=\"page_view_search("+llen+","+spp+",1,"+mtch+",'"+r+"','"+obj+"');\">&nbsp;<b>FIRST</b>&nbsp;</td>";
}
start=Math.max(1,spage-2); //minus 2 will show two pages to the left of the current page
finish=Math.min(pages,spage+2); //plus 2 will show two pages to the right of the current page
for(i=start;i<=finish;i++){
if(i<spage){
if(bck>1){
oHTML+="<td class='pv' onclick=\"page_view_search("+llen+","+spp+","+i+","+mtch+",'"+r+"','"+obj+"');\">&nbsp;<b>"+i+"</b>&nbsp;</td>";
}
}else if(i===spage){ //If page is this page show non-selectable number only
oHTML+="<td class='pvtxt pvsel'>&nbsp;"+spage+"&nbsp;</td>";
}else if(spage+1<pages){
oHTML+="<td class='pv' onclick=\"page_view_search("+llen+","+spp+","+i+","+mtch+",'"+r+"','"+obj+"');\">&nbsp;<b>"+i+"</b>&nbsp;</td>";
}
}
nxt=spage+1;
if(nxt<pages){ 
oHTML+="<td class='pv' onclick=\"page_view_search("+llen+","+spp+","+nxt+","+mtch+",'"+r+"','"+obj+"');\">&nbsp;<b>NEXT</b>&nbsp;</td>";
}else if(spage<pages){ //If next page is the last page
oHTML+="<td class='pv' onclick=\"page_view_search("+llen+","+spp+","+pages+","+mtch+",'"+r+"','"+obj+"');\">&nbsp;<b>LAST</b>&nbsp;</td>";
}
oHTML+="<td><ul class='pvmenu'><li>&nbsp;PAGE&nbsp;<ul>";
for(i=1;i<pages+1;i++){ //Loop through all page numbers and display in drop down box
if(i===spage){ //If page is this page in the drop down box show as hled non-selectable
oHTML+="<li class='pvsel'>&nbsp;PAGE&nbsp;"+i+"&nbsp;</li>";
}else{
oHTML+="<li onclick=\"page_view_search("+llen+","+spp+","+i+","+mtch+",'"+r+"','"+obj+"');\">&nbsp;PAGE&nbsp;"+i+"&nbsp;</li>";
}
}
oHTML+="</ul></li></ul></td>";
oHTML+="</tr></table></td></tr></table>";
}
document.getElementById("pv").innerHTML=oHTML; //Show generated HTML
}

////

function kwords_show(r,xid,tf){ //Comes here when you select a keyword produced by user input
	//console.log("kwords_show");
var xids=[];
if(tf===0){
xids[0]=xid;
}else{
xids=res[xid]["itemids"];
}
litems="search"; //So we know the search facility is being used
temp_join(r,true,xids); //Render search results on screen
}

////

function ExpandHide(id,fcs){ //Opens and closes Search Bar etc
	//console.log("ExpandHide");
if(document.getElementById("div_"+id).style.display==="block"){ //Checks if visible
document.getElementById("div_"+id).style.display="none"; //Makes invisible
document.getElementById("img_"+id).className="arrowdown"; //Change arrow icon
}else{
document.getElementById("div_"+id).style.display="block"; //Make visible
document.getElementById("img_"+id).className="arrowup"; //Change arrow icon
if(fcs!==""){
document.getElementById(fcs).focus(); //Where to set the cursor focus
}
}
}

////

function sort_object(ob,fld,na,tf){ //Sorts an object keyed array without index numbers using fld ascending
	//console.log("sort_object");
var i,l,key,keys=[],srtd=[],sort_temp=[];
keys=get_keys(ob); //Create array of keys
l=keys.length;
for(key=0;key<l;key++){
sort_temp[key]=ob[keys[key]]; //Store the whole array
sort_temp[key]["k"]=keys[key]; //Add the key value field to the array so we can sort and maybe restore it later
}
sort_temp=sortjsonfld(sort_temp,fld,na); //Sort by specified field
if(tf===false){ //If false we do not revert things back to using named-keys because if they are numbers they will not stay sorted as performed above and be exactly as they were
return sort_temp;
}else{
l=keys.length;
for(i=0;i<l;i++){
srtd[sort_temp[i]["k"]]=ob[sort_temp[i]["k"]]; //Loop through putting the array back using the original keys. Must not be numbers to retain the changed sort order
}
return srtd;
}
}

////

function sortjsonfld(ry,fld,na){ //Sorts a numerical indexed array by the specified field name
	//console.log("sortjsonfld");
if(ry){
if(na.toUpperCase()==="N"){ //Numerical order ascending only. Any strings would be 0 so you must only have numbers in the field to use this option effectively.
ry.sort(function(a,b){
return a[fld]-b[fld];
});
}else{ //Alphabetical order ascending only. Note: 'Option 10' would come before 'Option 2'. It is advisable therefore to utilise the 'sort' field to guarantee the correct order you desire
ry.sort(function(a,b){
if(a[fld]<b[fld]){
return -1;
}else if(a[fld]>b[fld]){
return 1;
}else{
return 0;
}
});
}
}
return ry;
}

////

function hl_sort(r,nm,AN){
	//console.log("hl_sort");
var prev,oni,st,img,sort_chngd;
sort_chngd=false; //Default to false
st=sort_type.split("_"); //Split sort selection in order to process what to do
if(st[1]==="asc"&&st[0]===nm){ //If name match it is the same option so we reverse the sort direction
ascdesc="desc"; //Reverse sort direction
img="arrowdown"; //Change arrow direction
}else{
ascdesc="asc"; //Change sort direction to ascending if descending or a new selection
img="arrowup"; //Change arrow direction
}
sort_type=nm+"_"+ascdesc; //Store latest sort selection by tagging together these 3 variables
document.getElementById("img"+nm).className=img; //Set direction arrow
//Array is only sorted ascending upon a new selection after which it does not sort again until there is a new selection
//It loops through backwards instead so you can click the same option as many times as you like, it will not sort again making things even more efficient and therefore faster
if(st[0]!=nm){ //If sort selection changed
prev=st[0];
oni=document.getElementById("selected"+prev);
if(oni){
oni.className="sort"; //Change current selection style to unselected 
document.getElementById("img"+prev).className="arrowup"; //Change current selection image to arrow up
}
document.getElementById("selected"+nm).className="sortsel"; //Change new selection style to selected
items=sortjsonfld(items,nm,AN); //Sort items in ascending order by default only with this new selection
sort_chngd=true; //Register that sort has been changed so the results will update on screen
sub_cats_cnt_xitems(); //Recalibrate items indexes per sub category now there has been a sort change
if(main_sub===false){ //If sub category selections dominate
main_cats_cnt_xitems(r,sort_chngd); //Now there has been a new selection and a physical sort change we need to recalibrate the linked items
}
}
//We need to know what results need updating on te page now the sort order has been changed
if(litems==="all"||litems==="new"){ //If it's the manage view all or new items
linkeditems(litems,sort_chngd);
}else{ //else if litems="main, sub or search"
s_results(r,"sort",true,sort_chngd); //If we're dealing with sub, main categories or the search results to update
}
}

////

function hl_main(r,xid,id){
	//console.log("hl_main");
var chngd,oni,ofrm="main",nm="_cat_";
chngd=false;
oni=document.getElementById(ofrm+nm+id+"selected"); //Store element for multiple use
if(xid==="reselect"){ //Reselecting the previous selection which was removed due to processing other data
if(oni){ //Check the element exists first
oni.className="t1sel"; //Change style to selected
sel_main_cat=id; //Store main category selection
chngd=true; //Set changed state so the results will update
}
}else{ //There is only one selection allowed so it's easier to deal with
if(sel_main_cat==id){ //If the user selection is exactly the same as it was then no need to update the page
if(document.getElementById("show_results").style.display==="none"||document.getElementById("show_results").innerHTML===""){ //Makes it render results on a same selection only if results are blank
chngd=true; //Change detected so results will update
}
}else{
chngd=true;
oni.className="t1sel"; //Change style to selected
if(document.getElementById(ofrm+nm+sel_main_cat+"selected")){ //Check if previous selection is valid before changing
document.getElementById(ofrm+nm+sel_main_cat+"selected").className="t1"; //Change previous selection style to default
}
sel_main_cat=id; //Store main category selection
}
}
s_results(r,ofrm,chngd,false);
}

////

function hl_sub_single(r,xid,id){ //Sub categories are treated differently to main category options
	//console.log("hl_sub_single");
var i,syl,chngd,ofrm="sub",nm="_cat_";
chngd=false; //Default to false, no changes made
if(sel_sub_cats.length>0){ //Check to see if there is a previous selection because on first page load there will not be
i=sel_sub_cats[0]; //Set i to previous selection
}else{
i=""; //Set i to blank if there is no previous selection
}
if(subcats[xid]["qty"]>0){ //If qty count is zero then no need to update the page
if(i==xid){ //If the user selection is exactly the same as it was
if(litems==="search"||litems==="all"||litems==="new"||document.getElementById("show_results").style.display=="none"||document.getElementById("show_results").innerHTML==""){ //Makes it render results on a same selection only if results are blank or a different feature was being used
chngd=true; //Change detected so results will update
}
}else{
if(subcats[xid]["parentid"]=="0"){ //Check if new selection is tier 1
syl="t1sel"; //Define style as a tier 1 option
}else{
syl="t2sel"; //Define style as a tier 2 option
}
sel_sub_cats.length=0; //Empty selected sub categories array
sel_sub_cats[0]=xid; //Store option in entry 0 since it is a radio option therefore only one can be selected
subcats[xid]["tf"]=true; //Set checked state of new selection to true
chngd=true; //Change detected so results will update
document.getElementById(ofrm+nm+id+"selected").className=syl; //Change new selection style to selected
if(i!==""&&subcats[i]){ //If i is blank then a previous selection doesn't exist so we can't perform this part right now until it does
subcats[i]["tf"]=false; //Set checked state of previous selection to false
if(document.getElementById(ofrm+nm+subcats[i]["id"]+"selected")){ //Check to see if previous selection is still a valid one
if(subcats[i]["parentid"]=="0"){ //Check if a tier 1 selection
syl="t1"; //Set style as a tier 1 option
}else{
syl="t2"; //Set style as a tier 2 option
}
document.getElementById(ofrm+nm+subcats[i]["id"]+"selected").className=syl; //Change previous selection style to unselected
}
}
}
}
s_results(r,ofrm,chngd,false);
}

////

function hl_sub_multi(r,xid,id){
	//console.log("hl_sub_multi");
var x,l,g,ci,tf,syl,chngd,sidsel,sidqty,ofrm="sub",nm="_cat_";
chngd=false;
if(and_subs===true&&subcats[xid]["tf"]!==true){ //If 'and' comparing is being used and selection is not selected check to see if it can be
if(document.getElementById(ofrm+nm+id+"selected").className.search(/unsel/)>-1){ //If set to unselectable
//if(document.getElementById(ofrm+nm+id+"selected").className.length>5){ //Alternative to above. If more than 5 it must contain unsel because t1sel is the longest
chngd=false; //Set overall changed to false
return; //Leave function
}
}
if(subcats[xid]["tf"]===true){ //Checking check state
tf=false; //Set checked state to false, the opposite of what it was
syl=""; //Store selection style, the opposite of what it was
}else{
tf=true; //Set checked state to true, the opposite of what it was
syl="sel"; //Store selection styl, the opposite of what it was
}
chngd=false; //Set default state
if(one_block_subs===true){ //If true we need to only allow one selection per tier 1/2 block
g=subcats[xid]["parentid"]; //g is the tier 1/2 group id
if(g=="0"){ //If it is a tier 1 we use its id
g=subcats[xid]["id"]; //Store tier 1 id so it is grouped with its tier 2 sub categories
}
}
x=-1;
sel_sub_cats.length=0; //Clear all the user selected sub categories
l=subcats.length;
for(ci=0;ci<l;ci++){ //Loop through all entries in the sub categories array
if(document.getElementById(ofrm+nm+subcats[ci]["id"]+"selected")){ //See if option exists on the page because not all sub categories will be visible
sidsel=document.getElementById(ofrm+nm+subcats[ci]["id"]+"selected"); //Store the selected id for multiple use
sidqty=Number(document.getElementById(ofrm+nm+subcats[ci]["id"]+"qty").innerHTML); //Store sub category quantity match counter value
if(ci==xid){ //If it matches the one clicked by the user
if(subcats[ci]["parentid"]!="0"){ //If tier 2
sidsel.className="t2"+syl; //Set sub style to opposite of what it was
subcats[ci]["tf"]=tf; //Set checked state to the opposite of what it was
}else if(sidqty>0||auto_sel_tier2===true){
if(sidqty>0||one_block_subs===false){
sidsel.className="t1"+syl; //Set sub style to opposite of what it was
subcats[ci]["tf"]=tf; //Set checked state to the opposite of what it was
}
}
if(sidqty>0){ //If quantity matches in greater than zero set changed to true so the page will update results
chngd=true;
}
}else if(one_block_subs===false&&auto_sel_tier2===true&&id==subcats[ci]["parentid"]&&sidqty>0){ //If auto select tier 2 is true and the selection is a top tier category it will also set the check state of all second tier categories under it the same
if(subcats[ci]["tf"]!==tf){ //Only automatically change tier 2 subs if the state changes as it could have been previously selected independandly
subcats[ci]["tf"]=tf; //Sets all second tier checked state to tf
sidsel.className="t2"+syl; //Sets all second tier new style
chngd=true; //Results will now update on the page
}
}else if(tf===true&&subcats[ci]["tf"]===true&&one_block_subs===true){ //First tf must be true and this option must also be true to continue matching criteria. Then one block subs must also be true, which only allows one selection per tier 1/2 block
if(subcats[ci]["parentid"]==g){ //If parent id matches the new selection parent block id
subcats[ci]["tf"]=false; //Change check state to false since only one per block is allowed
sidsel.className="t2"; //Reset all second tier style
chngd=true; //true required to update page results
}else if(subcats[ci]["id"]==g){ //If tier 1 id matches the new selection parent block
subcats[ci]["tf"]=false; //Change check state to false since only one per block is allowed
sidsel.className="t1"; //Reset all second tier style
chngd=true; //true required to update page results
}
}
if(subcats[ci]["tf"]===true&&sidqty>0){ //If check state is true and there are matches
x++;
sel_sub_cats[x]=ci; //Faster storing the selected sub categories in a separate array by index
}
}
}
s_results(r,ofrm,chngd,false);
}

////

function s_results(r,f,c,sc){
	//console.log("s_results");
if(f!=="sort"&&litems==="search"){ //If search facility was used and then switched back to category selection
c=true; //Over rides any previous setting because we have moved from the search facility back to the categories so it needs to render the results
document.getElementById("div_kws").style.display="none"; //Makes invisible
document.getElementById("img_kws").className="arrowdown"; //Change arrow icon
}
if(c===true){ //Something must change in order to re-render the page details
if(f!=="sort"){
litems=f; //When the manage facility is used we store this value after a sort or category change so it shows the results of these instead of 'all' or 'new' added items results
}
if(main_sub===true){ 
main_sub_results(r,f,sc); //If the main category selection dominates
}else{
sub_main_results(r,f,sc); //If the sub category selection dominates
}
}
}

////

function or_subs(){
	//console.log("or_subs");
//Creates 'or' results of each sub category tier 1/2 blocks
var i,ii,l,l1,l2,key,keys=[],og=[],xi=[];
og.length=0; //Clear og
l=sel_sub_cats.length;
for(i=0;i<l;i++){ //Loop through selected sub categories
key=subcats[sel_sub_cats[i]]["parentid"]; //Store group parent id
if(key=="0"){ //If a root Tier 1
key=subcats[sel_sub_cats[i]]["id"]; //If it is a tier 1 sub category we clump them together with its tier 2 selections using the shared parent id
}
xi=subcats[sel_sub_cats[i]]["xitems"]; //Store items[] index numbers for each selected sub category
l2=xi.length;
for(ii=0;ii<l2;ii++){ //Loop through them
if(!og[key]){ //Check if key named entry exists
og[key]=[]; //Creates empty array
og[key]["xitems"]=[]; //Adds empty xitems[] field
og[key]["andxitems"]=[]; //Adds empty anditems[] field
}
og[key]["xitems"][xi[ii]]=1; //Add indexes grouped by blocks using key names to prevent duplicates
}
}
keys=get_keys(og); //Create an array of og keys
l1=keys.length;
for(key=0;key<l1;key++){ //Loop through all rows by key
og[keys[key]]["xitems"]=get_keys(og[keys[key]]["xitems"]); //Converts xitems keys in to a standard array
}
return og; //Return 'or' sub groups so they can be 'and' processed
}

////

function subs_and_subs(og,m){ //Creates 'and' results using the 'or' blocks created above
	//console.log("subs_and_subs");
var i,ii,x,l,l2,key,keys=[],f,xid,xi,asubs=[],aasubs=[];
asubs.length=0;
keys=get_keys(og); //When the browser doesn't support the above
l=keys.length;
f=true; //Set default first set of indexes to compare as true before switching to false after the first set are stored
for(key=0;key<l;key++){
if(keys[key]!=m||m==="all"){
x=-1;
aasubs.length=0;
xi=og[keys[key]]["xitems"]; //Store next tier1/2 selected index numbers
l2=xi.length;
for(ii=0;ii<l2;ii++){ //Loop through next tier1/2 selected index numbers
xid=xi[ii];
if(f===true){ //If the first tier 1/2 block store all selections so we have something to compare with
x++;
aasubs[x]=xid;
}else if(asubs[xid]){ //If not the first block only store where they match with previous stored data creating an 'and and' result for all selected 'or blocks'
x++;
aasubs[x]=xid;
}
}
f=false; //First 'or' block has been stored for all subsequent blocks to compare with and each other so we set it to false so it now compares
asubs.length=0;
for(i=0;i<aasubs.length;i++){
asubs[aasubs[i]]=1; //Save only 'and and' subs to a key named array
}
}
}
return get_keys(asubs); //When the browser doesn't support the above
}

////

function desel(){
	//console.log("desel");
var x,i,l,ssc,qty,gl,gz,akey,akeys=[],sidqty,sidsel,ds,rec,og=[]; //Set default reconfigure selected sub categories state
og=or_subs(); //Return only items that can be found in all tier 1/2 blocks so the more sub categories selected the lower the results unless they are in the same tier 2 block. Tier 2 are always 'or' within its own block
nxk=subs_and_subs(og,"all"); //Using the 'or' subs groups we now process the 'and' matches. Second parameter is "all" so it includes all or groups otherwise it would exclude the defined id number
akeys=get_keys(og); //When the browser doesn't support the above
gl=akeys.length;
if(gl===1){ //If there is only 1 group it can't compare yet
gz=akeys[0]; //Store the block id for use only within the function selstate below
}else{
gz=0;
}
for(akey=0;akey<gl;akey++){ //Loop through array of keys
og[akeys[akey]]["andxitems"]=subs_and_subs(og,akeys[akey]); //Stores xitems that do not compare with its own block selections at all times which are present in all the other tier 1/2 blocks
}
rec=false; //Reconfigure default state
l=subcats.length; //All the sub categoriesssc=sel_sub_cats.length;
ssc=sel_sub_cats.length; //The already selected sub categories
for(i=0;i<l;i++){ //Loop through all sub categories
if(document.getElementById("sub_cat_"+subcats[i]["id"]+"selected")){ //Checking if page element exists first
sidsel=document.getElementById("sub_cat_"+subcats[i]["id"]+"selected"); //Store style element id
sidqty=document.getElementById("sub_cat_"+subcats[i]["id"]+"qty"); //Store quantity element id
if(ssc>0){
ds=selstate(gl,gz,i,sidsel,sidqty,og); //Process each sub category against short listed xitems to see if it is selectable or not
if(ds===true){ //If deselect is true because a previously selected option became unselectable. This is possible when there are multiple selections in the same tier 1/2 block
rec=true; //Set rec to true so the selected sub categories and matched items are reconfigured at the end. Once true it can not revert back to false until everything is reconfigured again
}
}else{ //If there are no selections at all then the counters are restored back to their original values
subcats[i]["tf"]=""; //Reset all check state values
qty=subcats[i]["qty"];
if(subcats[i]["parentid"]=="0"){ //If a tier 1 sub category we change the style accordingly
if(qty>0){
sidsel.className="t1"; //Reset back to original tier 1 style
sidqty.className="bq"; //Update class to original black
sidqty.innerHTML=qty; //Update quantity back to original value
}else{
sidsel.className="t1unsel"; //Reset back to original tier 1 style
}
}else{ //If a tier 2 sub category we change the style accordingly
sidsel.className="t2"; //Reset back to original tier 2 style
sidqty.className="bq"; //Update class to original black
sidqty.innerHTML=qty; //Update quantity back to original value
}
}
}
}
if(rec===true){ //If true we need to refresh and correct the sub category selections due to changes in the status of some previously selected which in turn changes the overall result matches
sel_sub_cats.length=0; //Clear user sub categories selections
l=subcats.length;
x=-1;
for(i=0;i<l;i++){ //Loop through all sub categories
if(subcats[i]["tf"]===true){ //If check state is still true store selected sub category
x++;
sel_sub_cats[x]=i; //Store indexes of selected sub categories
}
}
return desel(); //return is used to break the loop
}
}

////

function selstate(gl,gz,i,sidsel,sidqty,og){
	//console.log("selstate");
var l1,l2,g,dsel,ds,clss,qty,nx1,nx2,anxk=[];
dsel=false; //Set default reconfigure selected sub categories state
ds=false; //Deselect default state
qty=0; //Reset counter for next sub category in the loop
g=subcats[i]["parentid"]; //Store block parent id
if(g=="0"){
g=subcats[i]["id"]; //Store block linked parent id
clss="t1"; //Tier 1 default class
}else{
clss="t2"; //Tier 2 default class
}
if(gl>1){ //If there are more than 1 'or' groups we can compare
if(og[g]){
anxk=og[g]["andxitems"]; //We use all the blocks and blocks except those in this block so they all stay active if they would produce results
}else{
anxk=nxk; //We use all the matches for all blocks and blocks because this tier 1/2 block has no selections within it
}
}else{
anxk=nxk; //We use all the matches for all blocks and blocks since there are only selections in just one tier 1/2 block
}
if(gl==1&&g==gz){ //There is only one group so it has to be excluded from matching routines so it doesn't match against itself so all options stay valid
if(subcats[i]["parentid"]!="0"||subcats[i]["qty"]>0){
sidqty.innerHTML=subcats[i]["qty"]; //Restore the original, retained, items quantity
sidqty.className="bq"; //Black counter style
}else if(subcats[i]["parentid"]=="0"&&subcats[i]["qty"]=="0"){
if(auto_sel_tier2===false||one_block_subs===true){ //Single select only
clss+="unsel"; //Change class to unselectable as a tier 1 sole selection
}
}
if(subcats[i]["tf"]!==true){ //Only if it is not checked do we need to restore the style and it could be blank or false
sidsel.className=clss; //Restore original default unselected style
}
}else{
l2=subcats[i]["xitems"].length; //Items indexes linked to this sub category
l1=anxk.length; //Short listed item indexes we are comparing/matching with
for(nx2=0;nx2<l2;nx2++){ //Loop through items indexes for each sub category
for(nx1=0;nx1<l1;nx1++){ //Loop through short listed items indexes
if(anxk[nx1]==subcats[i]["xitems"][nx2]){ //If a match
qty++; //Quantity of matches where the items id is in both the current total items already shortlisted and this particular sub category for each and every sub category
break; //Index value can only exist and be counted in a sub category xitems once
}
}
}
if(qty===0){ //If no matches found
if(Number(sidqty.innerHTML)>0){
if(subcats[i]["parentid"]=="0"){ //If a tier 1 sub category we need to check if it has any tier 2 sub categories
if(subcats[i]["xsubs"].length===0||one_block_subs===true){ //Only if it becomes the sole selection for this block because there are no tier 2 or one block subs is set to true
ds=true; //It's a tier 1 as a sole possible selection so deselect
sidqty.innerHTML=qty; //Update screen quantity
sidqty.className="rq"; //Red zero counter style
}else if(subcats[i]["qty"]>0){
sidqty.innerHTML=qty; //Update screen quantity
sidqty.className="rq"; //Red zero counter style
}
}else{
ds=true; //If tier 2 has no matches it will become unselectable because there are no other conditions to prevent this as with tier 1's
sidqty.innerHTML=qty; //Update screen quantity
sidqty.className="rq"; //Red zero counter style
}
}
if(ds===true){ //If deselect is true change style accordingly
sidsel.className=clss+" unsel"; //Change to unselectable style
if(subcats[i]["tf"]===true){ //It is possible for a previous selection within a block to now become zero and therefore not selectable any more
subcats[i]["tf"]=false; //Change check state to false
dsel=true; //Now we need to reconfigure selected sub cats because a previously selected option no longer can be. This can happen where more than 1 selection is made within the same tier 1/2 block
}
}
}else{
if(subcats[i]["tf"]!==true){ //Only if it is not checked do we need to restore the style and it could be blank or false
sidsel.className=clss; //Restore original default unselected style
}
sidqty.innerHTML=qty; //Update screen quantity
sidqty.className="gq"; //Using updated style
}
}
return dsel;
}

////

function get_keys(o){ 
return Object.keys(o); //Return array of keys
}

////

function trm(s){
return s.trim(); //Return trimmed of blank spaces in front and behind
}