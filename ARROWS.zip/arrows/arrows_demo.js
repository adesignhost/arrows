/*Copyright Aidan Woodrow aDesignHost.co.uk 2021. All rights reserved. WARNING: This line must not be removed.*/
//Main category or sub category dominance template
//This function adds extra user functionality but you can remove it as a user option and hard wire your desired 'main_sub=true or false' choice in to the code instead
//Main categories are always single select but main_sub=true means that when you select one it will process what sub categories are linked with it. false means when you select a sub category it will process which main categories are linked with it but sub categories can be multi select
function main_sub_dominance(result){
var oHTML,main_class,sub_class;
if(main_sub===true){ //Highlights the correct default selection
main_class="t1sel";
sub_class="t1";
}else{
main_class="t1";
sub_class="t1sel";
}
oHTML="<ul class='sidebar acenter'>";
oHTML+="<li class='heading rbg'>Main or Sub Dominance</li>";
oHTML+="<li class='"+main_class+"' id='ms_main' onclick=\"show_main_cats('"+result+"');document.getElementById('ms_main').className='t1sel';document.getElementById('ms_sub').className='t1';\">Main Category Dominance</li>";
oHTML+="<li class='"+sub_class+"' id='ms_sub' onclick=\"restore_sub_cats_2tiers('"+result+"');document.getElementById('ms_main').className='t1';document.getElementById('ms_sub').className='t1sel';document.getElementById('or_subs').click();\">Sub Category Dominance</li>";
oHTML+="</ul>";
document.getElementById("options").innerHTML+=oHTML; //Append side options with this template
}

////

//This function adds extra user functionality but you can remove it as a user option and hard wire your desired 'main_sub=true or false' choice in to the code instead
function restore_sub_cats_2tiers(result){
main_sub=false; //Sub categories now dominate
sub_cats_cnt_xitems(); //Links all items by index with matching sub category
cats_xsubs(); //Processes all tier 2 sub categories, should there be any
sub_cats_2tiers(result); //Shows all sub categories
sub_main_results(result,"sub",false); //Shows results using existing previous selections
}

////

function reset_sub_cats_2tiers(result){
var i,l=subcats.length;
for(i=0;i<l;i++){
subcats[i]["tf"]=""; //Reset check states
}
sub_cats_2tiers(result);
}

////SUB CATEGORY OPTIONS
//Single or Multi Options template
//This adds extra user functionality but you can remove it as a user option and hard wire your desired choice in to the code instead
function single_multi(result){
var oHTML,classradio,classcheckbox;
if(rcbox=="single"){ //Single selection
classradio="t1sel";
classcheckbox="t1";
}else{ //Multi selection
classradio="t1";
classcheckbox="t1sel";
}
oHTML="<ul class='sidebar acenter'>";
//On screen single or multi select categories
oHTML+="<li class='heading rbg'>Single/Multi Select Subs</li>";
//Changes selection, sets radio (single) or checkbox (multi) value, changes to or subs only for single select only
oHTML+="<li class='"+classradio+"' id='sm_single' onclick=\"document.getElementById('sm_single').className='t1sel';document.getElementById('sm_multi').className='t1';rcbox='single';reset_sub_cats_2tiers('"+result+"');document.getElementById('or_subs').click();\">Single Selection</li>";
oHTML+="<li class='"+classcheckbox+"' id='sm_multi' onclick=\"document.getElementById('sm_single').className='t1';document.getElementById('sm_multi').className='t1sel';rcbox='multi';reset_sub_cats_2tiers('"+result+"');\">Multi Selections</li>";
oHTML+="</ul>";
document.getElementById("options").innerHTML+=oHTML; //Appending this template to the options side menu
}

////

function and_or_subs(result,and_subs){
////SUB CATEGORY AND/OR OPTIONS
//This adds extra user functionality but you can remove it as a user option and hard wire your desired choice in to the code instead
var oHTML,andclass,orclass;
if(and_subs===true){ //Single selection
andclass="t1sel";
orclass="t1";
}else{ //Multi selection
andclass="t1";
orclass="t1sel";
}
oHTML="<ul class='sidebar acenter'>";
oHTML+="<li class='heading rbg'>Subs AND/OR Subs</li>";
oHTML+="<li class='"+andclass+"' id='and_subs' onclick=\"document.getElementById('and_subs').className='t1sel';document.getElementById('or_subs').className='t1';and_subs=true;document.getElementById('sm_multi').click();\">Tier 1&2 Subs AND Subs</li>";
oHTML+="<li class='"+orclass+"' id='or_subs' onclick=\"document.getElementById('and_subs').className='t1';document.getElementById('or_subs').className='t1sel';and_subs=false;reset_sub_cats_2tiers('"+result+"');\">Tier 1&2 Subs OR Subs</li>";
oHTML+="</ul>";
document.getElementById("options").innerHTML+=oHTML; //Appending this template to the options side menu
}

////

function one_per_group(result,one_block_subs){
////SUB CATEGORY BLOCK SETTING
//Providing other settings are not over riding it you can choose to allow 1 selection per block or multi selections per each tier 1/2 block
var oHTML,oneclass,allclass;
if(one_block_subs===true){ //Single selection
oneclass="t1sel";
allclass="t1";
}else{ //Multi selection
oneclass="t1";
allclass="t1sel";
}
oHTML="<ul class='sidebar acenter'>";
oHTML+="<li class='heading rbg'>Selections Per Block</li>";
oHTML+="<li class='"+oneclass+"' id='one_group' onclick=\"document.getElementById('one_group').className='t1sel';document.getElementById('all_group').className='t1';one_block_subs=true;reset_sub_cats_2tiers('"+result+"');\">One Each Tier 1/2 Group</li>";
oHTML+="<li class='"+allclass+"' id='all_group' onclick=\"document.getElementById('one_group').className='t1';document.getElementById('all_group').className='t1sel';one_block_subs=false;reset_sub_cats_2tiers('"+result+"');\">Multi Each Tier 1/2 Group</li>";
oHTML+="</ul>";
document.getElementById("options").innerHTML+=oHTML; //Appending this template to the options side menu
}

////

function showhidecontent(idshow,idhide){
document.getElementById(idhide).style.display="none"; //Hide this id
document.getElementById(idshow).style.display="block"; //Making this id visible
}

////

function newcontent(nc){ //Here you can continue the same theme using templates and JSON array data
document.getElementById("show_results").style.display="none"; //Just hiding the results ID
document.getElementById("morecontent").innerHTML=document.getElementById(nc).innerHTML; //Filling the morecontents ID with the new info
document.getElementById("morecontent").style.display="block"; //Make it visible
}

function backtoresults(){
document.getElementById("morecontent").style.display="none"; //Just hiding the morecontents ID
document.getElementById("morecontent").innerHTML=""; //Making sure it is blank
document.getElementById("show_results").style.display="block"; //Making results ID visible again.
}