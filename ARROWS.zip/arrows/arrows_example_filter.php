<?php
/*Copyright Aidan Woodrow aDesignHost.co.uk 2021. All rights reserved. WARNING: This line must not be removed.*/
include("arrows_example_data.php"); //Collecting all the data
//Now the arrays are full with data we JSON encode them so they can be used in JavaScript
$items=json_encode($items); //Result items converted to JSON
$kwords=json_encode($allkw); //Search keywords converted to JSON
?>
<!--Side menus go in here-->
<tr><td class="vatop">
<div id="options" class="sidebar aleft"></div>
</td>
<!--Main content goes here-->
<td class="vatop tbl">
<div class="acenter vlcorner gbg heading">Versatile Menu & Content Filter with Search Facility & Management Functions</div>
<div class="acenter whhead">»ARROWS«<div class="acenter wh">"Makes doing something very useful, very easy and very fast"</div></div>
<div class="acenter wh" id="result_count"></div> <!--Position to show records found. You can remove if you don't want to display this but you also need to remove the line which populates this id in the arrows_filter.js too-->
<div id="search_results"></div> <!--Keyword results-->
<div id="show_results"></div> <!--Selection results-->
<div id="morecontent" class="wh"></div> <!--More content can be displayed here or where ever you choose-->
</td></tr>

<script>
////1) MAIN CATEGORIES. If these will be semi-permanently hard wired you should remove them from this PHP file and put it inside the arrows_filter JS file instead so they will be cached
//As long as the main_cat in the items[] array is a correct match with one of these maincats[keys] so M0, M1 etc then it will work
var maincats=[]; //Always prefix the key name with an 'M' or another letter to make sure it is a key and not an array
maincats.length=0;
maincats["M0"]={"mc":"Inkjet Cartridges","sort":"10","qty":0,"xitems":[]};
maincats["M1"]={"mc":"Laser Toners","sort":"20","qty":0,"xitems":[]};
maincats["M2"]={"mc":"Ribbons Dot Matrix","sort":"30","qty":0,"xitems":[]};
maincats["M3"]={"mc":"Inkjet Refilling","sort":"40","qty":0,"xitems":[]};
maincats["M4"]={"mc":"Inkjet Paper","sort":"50","qty":0,"xitems":[]};
//You don't need to sort these if you put them in the correct order so that function can be missed out and the sort field can be removed
//If you are going to sort it then you must use a character prefix (as numbers can become indexes and we want to use keys) in the key with the same unique id number that will also be stored in the items[] array, where its data will come from a database
maincats=sort_object(maincats,"sort","A",true); //Sort a named-key object by the "sort" field Alphabetically keeping its original key value. If you store them already sorted (advised) then you won't need to do this


////2) SUB CATEGORIES. If these will be semi-permanently hard wired you should remove them from this PHP file and put it inside the arrows_filter JS file instead so they will be cached
var subcats=[];
subcats.length=0;
subcats.push({"parentid":"0","id":"1","xsubs":[],"xitems":[],"name":"Selection 1","sort":"1","qty":0,"tf":""});
subcats.push({"parentid":"0","id":"2","xsubs":[],"xitems":[],"name":"Selection 2","sort":"2","qty":0,"tf":""});
subcats.push({"parentid":"0","id":"3","xsubs":[],"xitems":[],"name":"Selection 3","sort":"3","qty":0,"tf":""});
subcats.push({"parentid":"0","id":"4","xsubs":[],"xitems":[],"name":"Selection 4","sort":"4","qty":0,"tf":""});
subcats.push({"parentid":"0","id":"5","xsubs":[],"xitems":[],"name":"Selection 5","sort":"5","qty":0,"tf":""});
subcats.push({"parentid":"0","id":"6","xsubs":[],"xitems":[],"name":"Selection 6","sort":"6","qty":0,"tf":""});
subcats.push({"parentid":"0","id":"7","xsubs":[],"xitems":[],"name":"Selection 7","sort":"7","qty":0,"tf":""});

subcats.push({"parentid":"1","id":"8","xsubs":[],"xitems":[],"name":"Selection 8","sort":"8","qty":0,"tf":""});
subcats.push({"parentid":"1","id":"9","xsubs":[],"xitems":[],"name":"Selection 9","sort":"9","qty":0,"tf":""});
subcats.push({"parentid":"1","id":"10","xsubs":[],"xitems":[],"name":"Selection 10","sort":"10","qty":0,"tf":""});

subcats.push({"parentid":"3","id":"11","xsubs":[],"xitems":[],"name":"Selection 11","sort":"11","qty":0,"tf":""});
subcats.push({"parentid":"5","id":"12","xsubs":[],"xitems":[],"name":"Selection 12","sort":"12","qty":0,"tf":""});
subcats.push({"parentid":"7","id":"13","xsubs":[],"xitems":[],"name":"Selection 13","sort":"13","qty":0,"tf":""});

subcats=sortjsonfld(subcats,"sort","N"); //Easier managing sort orders using Numbers only. If you want to sort Alphabetically then just change the value "sort" to "name" and change "N" to "A" 
cats_xsubs(); //Collate all the sub categories by index an option may have. Warning: This must and only be performed after sorting subcats and not before


////6) Sorting. If these will be permanently hard wired you should remove them from this PHP file and put it inside the JS file instead so they will be cached
var srt_fld="sorttitle"; //This field can be anything defined in items[] It doesn't matter if this data is displayed on screen or not
var option="Title"; //This field is for the default option name
var slctd="t1sel"; //Default style class needs putting on the same line as srt_fld. t1 is unselected and t1sel is the selected style
var sortops=[]; //We don't sort these because the list is short so the order they are in here is the order they will be on the page
sortops.length=0;
//You can add as many as you like. You just need to make sure the "id":"field name" matches something in the items[] array whether it appears on screen or not
sortops.push({"id":srt_fld,"AN":"A","class":slctd,"option":option}); //Default sort field has the 'srt_fld' and 'slctd' variables
sortops.push({"id":"sortdate","AN":"N","class":"t1","option":"Date Updated"}); //AN donates 'A' for Alphabetical order or 'N' for Numerical order. For this data we must use the 'N' option
sortops.push({"id":"type","AN":"A","class":"t1","option":"Type"}); //id's must match items[] array field names


////7) JavaScript Global settings
var result="arrows"; //Unique page identifier so you can run other code through the same universal filter and perform specific tasks based on the result value.
var manage=false; //Allows you to edit associated item main and sub categories when set to true.
var main_sub=true; //true = main category selection dominates / false = sub category selection dominates. The demo allows you to toggle this option but you would hard code it.
//true means when you click a main category it will process what sub categories are related to it. false is the other way around so when you select a sub category it will process what main categories are related to it
//This is different to yourself swapping the main and sub categories in the original code because main categories are single select only but sub categories can be either single or multi select.
var and_subs=false; //true means item matches must be present in all sub category tier 1/2 blocks except its own block. false for 'or' results. If main_sub is set to false this parameter will be ignored
var one_block_subs=false; //If true only one selection per tier 1/2 blocks will be allowed. false will allow any number of valid selections in the same block
var rcbox="multi".toLowerCase(); //Determines whether sub categories are single or multi select. This will override any settings above if there is a conflict. Options: single or multi
var auto_sel_tier2=true; //If true when a tier 1 sub category is selected (multi select only) it will also select all tier 2 sub categories under it. false will not. You can still unselect them individually afterwards

////Transfers all collected data from PHP to JavaScript
var items=(<?php echo $items?>); //Transfers it to JavaScript we can use it client/browser side
var kwords=(<?php echo $kwords?>); //Transfers search keywords to JS
var min_search_len=1; //Minimum user input string length to perform the search. 1 means if they type just one letter it will begin to search. 2 or 3 should be used ideally to prevent too many matches


////8) Display all side menu options
//Display Templates only
sortoptions_template("Sort Options"); //Result is used to distinguish it from another separate complete system
main_category_template("Main Categories"); //Display main categories template only
sub_category_template("Sub Categories"); //Display sub categories template only


////9) Incorporate keywords search facility
if(kwords.length>0){ //Render search template if there is any data to search. 
kwords=keywords(kwords,min_search_len); //Sorts and processes keywords
search_template(result,"Search","title"); //result=unique id, "Search" is the heading, "?" is an items field to show as the titles
}


////10) Display data
sortoptions(result,sortops); //Insert sort options in to template
hl_sort(result,srt_fld,"A"); //Sorts items[] array using the field name in 'srt_fld' Alphabetically which in turn calibrates linked items with sub categories and also main categories if 'main_sub' is set to false above
if(main_sub===true){
show_main_cats(result); //Shows main categories only first
}else{
sub_cats_2tiers(result); //Shows sub categories only first
}

	////Manage options (When you click on the items manage options the variable manage becomes true so you can see and use its functions but does not return to false unless you refresh the whole page) 
	//This feature and associated code should only reside on a local machine, not on an on-line server so only you can make any changes.
	//if(manage===true){
	document.getElementById("options").innerHTML+=document.getElementById(result+"_manageoptions").innerHTML;
	main_sub_dominance(result);	//You would normally remove this line and function as a user option and hard code your 'main_sub' =true or =false choice. This is only here to show case the demo
	single_multi(result); //Toggle sub category single or multi select. You can remove this line and associated code as an end user option and hard wire your desired 'rcbox' choice above
	and_or_subs(result,and_subs); //Toggle sub and sub block / sub or sub block. You can remove this line and associated code as an end user option and hard wire your desired 'and_subs' choice above
	one_per_group(result,one_block_subs); //Show demo option to change number of selections per Tier 1/2 block
	document.getElementById("options").innerHTML+=document.getElementById(result+"_generaloptions").innerHTML; //Shows general options but if you do not want to display any of your own then you can remove this line and any associated code. It's not technically part of the filter. It's just here to show information in the easiest way possible.
	//}
</script>